<?php
require 'db.php';

$id=$_GET['id']??null;
if(!$id) exit;
if($_SERVER['REQUEST_METHOD']==='POST'){
    $fecha=$_POST['fecha']??'';
    $tipo=$_POST['tipo']??''; 
    $producto_nombre=$_POST['producto_nombre']??''; 
    $producto_id=$_POST['producto_id']??''; 
    $cantidad=$_POST['cantidad']??'';
    $motivo=$_POST['motivo']??''; 
    $usuario=$_POST['usuario']??'';
    
    // Nombres de las columnas en la BD: tipo_mov, nombre_prod, Productos_id_producto, descripcion
    $stmt=$pdo->prepare("UPDATE otrosmovimientos SET fecha=?,tipo_mov=?,nombre_prod=?,Productos_id_producto=?,cantidad=?,descripcion=?,usuario=? WHERE id_otrosMovimientos=?");
    $stmt->execute([$fecha, $tipo, $producto_nombre, (int)$producto_id, (int)$cantidad, $motivo, $usuario, $id]);
}
header("Location: ../om.php");
exit;