<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header("location: index.php");
}

require 'proveedores/db.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$search = $_GET['search'] ?? '';

// La tabla y la columna son correctas aquí: 'proveedores' y 'id_proveedores'
if ($search !== '') {
    $stmt = $pdo->prepare("SELECT * FROM provedores WHERE id_provedores = :id OR nombre LIKE :nombre ORDER BY id_provedores DESC");
    $stmt->execute([
        ':id' => $search,
        ':nombre' => "%$search%"
    ]);
} else {
    // ¡CORRECCIÓN CRÍTICA! Cambiado 'provedores' por 'proveedores' (nombre de tabla correcto)
    $stmt = $pdo->query("SELECT * FROM provedores ORDER BY id_provedores DESC"); 
}

$proveedores = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Proveedores - Inventario</title>
    <link rel="stylesheet" href="proveedores/style.css">
</head>
<body>
    <?php
    include ("menu.php");
    ?>

      <div class="scroll"></div>

<div class="container">
    <h1>Proveedores</h1>
    <div class="top-bar">
        <a class="btn btn-primary" href="proveedores/create.php">+ Nuevo proveedor</a>
        <form method="get" class="search">
            <input type="text" name="search" placeholder="Buscar por ID o nombre" value="<?= htmlspecialchars($search) ?>">
            <button class="btn" type="submit">Buscar</button>
            <a class="btn" href="proveedores.php">Limpiar</a>
        </form>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>RFC</th>
                <th>Email</th>
                <th>Teléfono</th>
                <th>Dirección</th>
                <th>Promotor</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        <?php if (count($proveedores) === 0): ?>
            <tr><td colspan="8">No se encontraron proveedores.</td></tr>
        <?php else: ?>
            <?php foreach ($proveedores as $p): ?>
            <tr>
                <td><?= $p['id_provedores'] ?></td>
                <td><?= htmlspecialchars($p['nombre']) ?></td>
                <td><?= htmlspecialchars($p['rfc']) ?></td>
                <td><?= htmlspecialchars($p['email']) ?></td>
                <td><?= htmlspecialchars($p['telefono']) ?></td>
                <td><?= htmlspecialchars($p['direccion']) ?></td>
                <td><?= htmlspecialchars($p['promotor']) ?></td>
                <td>
                    <a class="btn" href="proveedores/edit.php?id=<?= $p['id_provedores'] ?>">Editar</a>
                    <a class="btn btn-danger" href="proveedores/delete.php?id=<?= $p['id_provedores'] ?>" onclick="return confirm('¿Eliminar este proveedor?')">Eliminar</a>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>