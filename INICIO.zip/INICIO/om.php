<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header("location: index.php");
}
// RUTA VERIFICADA: db.php está en la subcarpeta
require 'otros_movimientos/db.php';

$filter = $_GET['tipo'] ?? 'Todos';
$edit_id = $_GET['edit'] ?? null;

// Traer movimientos, usando alias para mapear los nombres de la BD a variables comunes
$query = "SELECT id_otrosMovimientos AS id, fecha, tipo_mov AS tipo, nombre_prod AS producto, cantidad, descripcion AS motivo, usuario, Productos_id_producto FROM otrosmovimientos";
$params = [];
if ($filter !== 'Todos') { $query .= " WHERE tipo_mov=?"; $params[] = $filter; }
$query .= " ORDER BY fecha DESC";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$movimientos = $stmt->fetchAll();

// Totales por tipo
$count = ["Ingreso"=>0,"Devolución"=>0,"Ajuste"=>0,"Merma"=>0];
$totales = $pdo->query("SELECT tipo_mov AS tipo, COUNT(*) AS total FROM otrosmovimientos GROUP BY tipo_mov")->fetchAll();
foreach($totales as $t) $count[$t['tipo']] = $t['total'];

// Si se edita (datos necesarios si se usara un formulario de edición directo)
$edit_data = null;
if ($edit_id) {
    $stmt = $pdo->prepare("SELECT id_otrosMovimientos AS id, fecha, tipo_mov AS tipo, nombre_prod AS producto, cantidad, descripcion AS motivo, usuario, Productos_id_producto FROM otrosmovimientos WHERE id_otrosMovimientos=?");
    $stmt->execute([$edit_id]);
    $edit_data = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Otros Movimientos</title>
<link rel="stylesheet" href="otros_movimientos/style.css">

</head>
<body>
    <?php
    include ("menu.php");
    ?>

    
    <div class="scroll"></div>

<div class="container">
<h1>Otros Movimientos</h1>

<div class="cards">
    <div class="card"><div class="card-title">Ingresos</div><div class="card-value"><?= $count['Ingreso'] ?></div></div>
    <div class="card"><div class="card-title">Devoluciones</div><div class="card-value"><?= $count['Devolución'] ?></div></div>
    <div class="card"><div class="card-title">Ajustes</div><div class="card-value"><?= $count['Ajuste'] ?></div></div>
    <div class="card"><div class="card-title">Mermas</div><div class="card-value"><?= $count['Merma'] ?></div></div>
</div>

<button class="btn-primary" onclick="openModal('nuevo')">Nuevo Movimiento</button>

<div class="tabs">
<?php foreach(["Todos","Ingreso","Devolución","Ajuste","Merma"] as $t): ?>
    <a href="?tipo=<?= $t ?>" class="tab <?= $filter === $t?'active':'' ?>"><?= $t ?></a>
<?php endforeach; ?>
</div>

<div class="table-container">
<table>
<thead>
<tr><th>ID</th><th>Fecha</th><th>Tipo</th><th>Producto</th><th>Cantidad</th><th>Motivo</th><th>Usuario</th><th>Acciones</th></tr>
</thead>
<tbody>
<?php foreach($movimientos as $m): ?>
<tr>
<td><?= $m['id'] ?></td>
<td><?= $m['fecha'] ?></td>
<td><span class="badge <?= strtolower($m['tipo']) ?>"><?= $m['tipo'] ?></span></td>
<td><?= htmlspecialchars($m['producto']) ?></td>
<td class="<?= $m['cantidad']>0?'cantidad-pos':'cantidad-neg' ?>"><?= $m['cantidad'] ?></td>
<td><?= htmlspecialchars($m['motivo']) ?></td>
<td><?= htmlspecialchars($m['usuario']) ?></td>
<td>
<a href="#" onclick="openModal('editar', <?= $m['id'] ?>)">Editar</a> | 
<a href="otros_movimientos/delete.php?id=<?= $m['id'] ?>" onclick="return confirm('¿Eliminar movimiento?');">Eliminar</a>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>

<div class="modal-backdrop" id="modal">
    <div class="modal">
        <div class="modal-header">
            <h2 id="modal-title">Nuevo Movimiento</h2>
            <button class="close" onclick="closeModal()">×</button>
        </div>
        <div id="modal-content">
            <form id="form-movimiento" method="post">
                <input type="hidden" name="id" id="mov-id">
                <input type="hidden" name="producto_id" id="mov-producto-id">
                <label>Fecha</label>
                <input type="date" name="fecha" id="mov-fecha" required>
                <label>Tipo</label>
                <select name="tipo" id="mov-tipo" required>
                    <?php foreach(['Ingreso','Devolución','Ajuste','Merma'] as $t): ?>
                        <option value="<?= $t ?>"><?= $t ?></option>
                    <?php endforeach; ?>
                </select>
                <label>Producto (Nombre)</label>
                <input type="text" name="producto_nombre" id="mov-producto-nombre" autocomplete="off" required>
                <div id="sugerencias" style="position:absolute;background:#fff;width:330px;max-height:180px;overflow-y:auto;border:1px solid #ccc;border-radius:10px;display:none;z-index:999;"></div>
                <label>Cantidad</label>
                <input type="number" name="cantidad" id="mov-cantidad" required>
                <label>Motivo</label>
                <input type="text" name="motivo" id="mov-motivo" required>
                <label>Usuario</label>
                <input type="text" name="usuario" id="mov-usuario" required>
                <div style="margin-top:12px;">
                    <button type="submit" class="btn-primary" id="btn-submit">Guardar</button>
                    <a href="#" class="btn-secondary" onclick="closeModal()">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Modal
function openModal(tipo, id=null){
    document.getElementById("modal").classList.add("show");
    const title = document.getElementById("modal-title");
    const form = document.getElementById("form-movimiento");

    if(tipo==='nuevo'){
        title.innerText = "Nuevo Movimiento";
        // RUTA VERIFICADA: action para crear en la subcarpeta
        form.action = "otros_movimientos/create_modal.php";
        form.reset();
        document.getElementById("mov-id").value='';
        document.getElementById("mov-producto-id").value='';
    } else if(tipo==='editar' && id){
        title.innerText = "Editar Movimiento";
        // RUTA VERIFICADA: action para actualizar en la subcarpeta
        form.action = "otros_movimientos/update_modal.php?id="+id;
        // RUTA VERIFICADA: fetch para obtener datos en la subcarpeta
        fetch('otros_movimientos/get_movimiento.php?id='+id)
            .then(r=>r.json())
            .then(data=>{
                document.getElementById("mov-id").value=data.id;
                document.getElementById("mov-fecha").value=data.fecha;
                document.getElementById("mov-tipo").value=data.tipo;
                document.getElementById("mov-producto-nombre").value=data.producto;
                document.getElementById("mov-producto-id").value=data.Productos_id_producto;
                document.getElementById("mov-cantidad").value=data.cantidad;
                document.getElementById("mov-motivo").value=data.motivo;
                document.getElementById("mov-usuario").value=data.usuario;
            });
    }
}
function closeModal(){document.getElementById("modal").classList.remove("show");}

// Autocompletado producto
const input = document.getElementById("mov-producto-nombre");
const box = document.getElementById("sugerencias");
const inputId = document.getElementById("mov-producto-id");

input.addEventListener("input", ()=>{
    const texto = input.value.trim();
    if(texto.length<1){box.style.display="none"; inputId.value=''; return;}
    // RUTA VERIFICADA: fetch para autocompletar en la subcarpeta
    fetch("otros_movimientos/buscar_producto.php?q="+texto)
    .then(r=>r.json())
    .then(lista=>{
        if(lista.length===0){box.style.display="none"; inputId.value=''; return;}
        box.innerHTML="";
        lista.forEach(p=>{
            const div = document.createElement("div");
            div.textContent = p.nombre;
            div.style.padding="10px";
            div.style.cursor="pointer";
            div.addEventListener("click", ()=>{ 
                input.value=p.nombre; 
                inputId.value=p.id; 
                box.style.display="none"; 
            });
            box.appendChild(div);
        });
        const rect = input.getBoundingClientRect();
        box.style.position="absolute";
        box.style.top=(input.offsetTop+input.offsetHeight)+"px";
        box.style.left=input.offsetLeft+"px";
        box.style.display="block";
    });
});
</script>
</div>
</body>
</html>