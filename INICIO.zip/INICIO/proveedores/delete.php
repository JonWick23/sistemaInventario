<?php
require 'db.php';

// Recibir el ID por GET
$id_provedores = $_GET['id'] ?? null;

// Validar que sí exista
if ($id_provedores) {

    // DELETE correcto usando la columna real
    $stmt = $pdo->prepare("DELETE FROM provedores WHERE id_provedores = ?");
    $stmt->execute([$id_provedores]);
}

// Redirigir de regreso
header("Location: ../proveedores.php");
exit;
?>
