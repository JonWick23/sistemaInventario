<?php
require 'db.php';
$id = $_GET['id'] ?? null;
if(!$id) exit;
$stmt = $pdo->prepare("SELECT * FROM otros_movimientos WHERE id=?");
$stmt->execute([$id]);
$m = $stmt->fetch();
echo json_encode($m);
