<?php
require 'db.php';

$id = $_GET['id'] ?? ($_POST['id'] ?? null);
if (!$id) { header("Location: om.php"); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fecha = $_POST['fecha'] ?? '';
    $tipo = $_POST['tipo'] ?? '';
    $producto = trim($_POST['producto'] ?? '');
    $cantidad = $_POST['cantidad'] ?? '';
    $motivo = trim($_POST['motivo'] ?? '');
    $usuario = trim($_POST['usuario'] ?? '');

    $errors = [];
    if (!$fecha) $errors[] = "La fecha es obligatoria.";
    if (!$tipo) $errors[] = "El tipo es obligatorio.";
    if ($producto === '') $errors[] = "El producto es obligatorio.";
    if ($cantidad === '' || !is_numeric($cantidad)) $errors[] = "La cantidad es obligatoria y numérica.";
    if ($motivo === '') $errors[] = "El motivo es obligatorio.";
    if ($usuario === '') $errors[] = "El usuario es obligatorio.";

    if (empty($errors)) {
        $update = $pdo->prepare("UPDATE otros_movimientos SET fecha=?, tipo=?, producto=?, cantidad=?, motivo=?, usuario=? WHERE id=?");
        $update->execute([$fecha, $tipo, $producto, (int)$cantidad, $motivo, $usuario, $id]);
        header("Location: om.php");
        exit;
    }
}

$stmt = $pdo->prepare("SELECT * FROM otros_movimientos WHERE id = ?");
$stmt->execute([$id]);
$m = $stmt->fetch();
if (!$m) { header("Location: om.php"); exit; }
?>
<!doctype html>
<html lang="es">
<head><meta charset="utf-8"><title>Editar Movimiento</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
  <h1>Editar Movimiento #<?= htmlspecialchars($m['id']) ?></h1>
  <form method="post" action="update.php?id=<?= htmlspecialchars($m['id']) ?>">
    <label>Fecha</label>
    <input type="date" name="fecha" value="<?= htmlspecialchars($m['fecha']) ?>" required>
    <label>Tipo</label>
    <select name="tipo" required>
      <?php foreach (['Ingreso','Devolución','Ajuste','Merma'] as $t): ?>
        <option value="<?= $t ?>" <?= ($m['tipo'] === $t) ? 'selected' : '' ?>><?= $t ?></option>
      <?php endforeach; ?>
    </select>
    <label>Producto</label>
    <input type="text" name="producto" value="<?= htmlspecialchars($m['producto']) ?>" required>
    <label>Cantidad</label>
    <input type="number" name="cantidad" value="<?= htmlspecialchars($m['cantidad']) ?>" required>
    <label>Motivo</label>
    <input type="text" name="motivo" value="<?= htmlspecialchars($m['motivo']) ?>" required>
    <label>Usuario</label>
    <input type="text" name="usuario" value="<?= htmlspecialchars($m['usuario']) ?>" required>
    <div style="margin-top:12px;">
      <button class="btn-primary">Guardar cambios</button>
      <a href="index.php" class="btn-secondary">Cancelar</a>
    </div>
  </form>
</div>
</body>
</html>

