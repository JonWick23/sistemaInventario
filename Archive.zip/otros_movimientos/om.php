<?php
require 'db.php';

$filter = $_GET['tipo'] ?? 'Todos';
$edit_id = $_GET['edit'] ?? null;

// Traer movimientos
$query = "SELECT * FROM otros_movimientos";
$params = [];
if ($filter !== 'Todos') { $query .= " WHERE tipo=?"; $params[] = $filter; }
$query .= " ORDER BY fecha DESC";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$movimientos = $stmt->fetchAll();

// Totales
$count = ["Ingreso"=>0,"Devolución"=>0,"Ajuste"=>0,"Merma"=>0];
$totales = $pdo->query("SELECT tipo, COUNT(*) AS total FROM otros_movimientos GROUP BY tipo")->fetchAll();
foreach($totales as $t) $count[$t['tipo']] = $t['total'];

// Si se edita
$edit_data = null;
if ($edit_id) {
    $stmt = $pdo->prepare("SELECT * FROM otros_movimientos WHERE id=?");
    $stmt->execute([$edit_id]);
    $edit_data = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Otros Movimientos</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<h1>Otros Movimientos</h1>

<div class="cards">
    <div class="card"><div class="card-title">Ingresos</div><div class="card-value"><?= $count['Ingreso'] ?></div></div>
    <div class="card"><div class="card-title">Devoluciones</div><div class="card-value"><?= $count['Devolución'] ?></div></div>
    <div class="card"><div class="card-title">Ajustes</div><div class="card-value"><?= $count['Ajuste'] ?></div></div>
    <div class="card"><div class="card-title">Mermas</div><div class="card-value"><?= $count['Merma'] ?></div></div>
</div>

<button class="btn-primary" onclick="openModal('nuevo')">Nuevo Movimiento</button>

<div class="tabs">
<?php foreach(["Todos","Ingreso","Devolución","Ajuste","Merma"] as $t): ?>
    <a href="?tipo=<?= $t ?>" class="tab <?= $filter === $t?'active':'' ?>"><?= $t ?></a>
<?php endforeach; ?>
</div>

<div class="table-container">
<table>
<thead>
<tr><th>ID</th><th>Fecha</th><th>Tipo</th><th>Producto</th><th>Cantidad</th><th>Motivo</th><th>Usuario</th><th>Acciones</th></tr>
</thead>
<tbody>
<?php foreach($movimientos as $m): ?>
<tr>
<td><?= $m['id'] ?></td>
<td><?= $m['fecha'] ?></td>
<td><span class="badge <?= strtolower($m['tipo']) ?>"><?= $m['tipo'] ?></span></td>
<td><?= htmlspecialchars($m['producto']) ?></td>
<td class="<?= $m['cantidad']>0?'cantidad-pos':'cantidad-neg' ?>"><?= $m['cantidad'] ?></td>
<td><?= htmlspecialchars($m['motivo']) ?></td>
<td><?= htmlspecialchars($m['usuario']) ?></td>
<td>
<a href="#" onclick="openModal('editar', <?= $m['id'] ?>)">Editar</a> | 
<a href="delete.php?id=<?= $m['id'] ?>" onclick="return confirm('¿Eliminar movimiento?');">Eliminar</a>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>

<!-- MODAL -->
<div class="modal-backdrop" id="modal">
    <div class="modal">
        <div class="modal-header">
            <h2 id="modal-title">Nuevo Movimiento</h2>
            <button class="close" onclick="closeModal()">×</button>
        </div>
        <div id="modal-content">
            <form id="form-movimiento" method="post">
                <input type="hidden" name="id" id="mov-id">
                <label>Fecha</label>
                <input type="date" name="fecha" id="mov-fecha" required>
                <label>Tipo</label>
                <select name="tipo" id="mov-tipo" required>
                    <?php foreach(['Ingreso','Devolución','Ajuste','Merma'] as $t): ?>
                        <option value="<?= $t ?>"><?= $t ?></option>
                    <?php endforeach; ?>
                </select>
                <label>Producto</label>
                <input type="text" name="producto" id="mov-producto" autocomplete="off" required>
                <div id="sugerencias" style="position:absolute;background:#fff;width:330px;max-height:180px;overflow-y:auto;border:1px solid #ccc;border-radius:10px;display:none;z-index:999;"></div>
                <label>Cantidad</label>
                <input type="number" name="cantidad" id="mov-cantidad" required>
                <label>Motivo</label>
                <input type="text" name="motivo" id="mov-motivo" required>
                <label>Usuario</label>
                <input type="text" name="usuario" id="mov-usuario" required>
                <div style="margin-top:12px;">
                    <button type="submit" class="btn-primary" id="btn-submit">Guardar</button>
                    <a href="#" class="btn-secondary" onclick="closeModal()">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Modal
function openModal(tipo, id=null){
    document.getElementById("modal").classList.add("show");
    const title = document.getElementById("modal-title");
    const form = document.getElementById("form-movimiento");
    const btn = document.getElementById("btn-submit");

    if(tipo==='nuevo'){
        title.innerText = "Nuevo Movimiento";
        form.action = "create_modal.php";
        form.reset();
        document.getElementById("mov-id").value='';
    } else if(tipo==='editar' && id){
        title.innerText = "Editar Movimiento";
        form.action = "update_modal.php?id="+id;
        fetch('get_movimiento.php?id='+id)
            .then(r=>r.json())
            .then(data=>{
                document.getElementById("mov-id").value=data.id;
                document.getElementById("mov-fecha").value=data.fecha;
                document.getElementById("mov-tipo").value=data.tipo;
                document.getElementById("mov-producto").value=data.producto;
                document.getElementById("mov-cantidad").value=data.cantidad;
                document.getElementById("mov-motivo").value=data.motivo;
                document.getElementById("mov-usuario").value=data.usuario;
            });
    }
}
function closeModal(){document.getElementById("modal").classList.remove("show");}

// Autocompletado producto
const input = document.getElementById("mov-producto");
const box = document.getElementById("sugerencias");
input.addEventListener("input", ()=>{
    const texto = input.value.trim();
    if(texto.length<1){box.style.display="none"; return;}
    fetch("buscar_producto.php?q="+texto)
    .then(r=>r.json())
    .then(lista=>{
        if(lista.length===0){box.style.display="none"; return;}
        box.innerHTML="";
        lista.forEach(p=>{
            const div = document.createElement("div");
            div.textContent = p;
            div.style.padding="10px";
            div.style.cursor="pointer";
            div.addEventListener("click", ()=>{ input.value=p; box.style.display="none"; });
            box.appendChild(div);
        });
        const rect = input.getBoundingClientRect();
        box.style.position="absolute";
        box.style.top=(input.offsetTop+input.offsetHeight)+"px";
        box.style.left=input.offsetLeft+"px";
        box.style.display="block";
    });
});
</script>
</div>
</body>
</html>

