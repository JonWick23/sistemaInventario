<?php
require 'db.php';
$id=$_GET['id']??null;
if(!$id) exit;
if($_SERVER['REQUEST_METHOD']==='POST'){
    $fecha=$_POST['fecha']??'';
    $tipo=$_POST['tipo']??'';
    $producto=$_POST['producto']??'';
    $cantidad=$_POST['cantidad']??'';
    $motivo=$_POST['motivo']??'';
    $usuario=$_POST['usuario']??'';
    $stmt=$pdo->prepare("UPDATE otros_movimientos SET fecha=?,tipo=?,producto=?,cantidad=?,motivo=?,usuario=? WHERE id=?");
    $stmt->execute([$fecha,$tipo,$producto,(int)$cantidad,$motivo,$usuario,$id]);
}
header("Location:om.php");
exit;
