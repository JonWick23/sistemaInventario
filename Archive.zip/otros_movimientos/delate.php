<?php
require 'db.php';

$id = $_GET['id'] ?? null;
if ($id) {
    $stmt = $pdo->prepare("DELETE FROM otros_movimientos WHERE id=?");
    $stmt->execute([$id]);
}
header("Location: om.php");
exit;


