<?php
require 'db.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $fecha=$_POST['fecha']??'';
    $tipo=$_POST['tipo']??'';
    $producto=$_POST['producto']??'';
    $cantidad=$_POST['cantidad']??'';
    $motivo=$_POST['motivo']??'';
    $usuario=$_POST['usuario']??'';
    $stmt=$pdo->prepare("INSERT INTO otros_movimientos(fecha,tipo,producto,cantidad,motivo,usuario) VALUES(?,?,?,?,?,?)");
    $stmt->execute([$fecha,$tipo,$producto,(int)$cantidad,$motivo,$usuario]);
}
header("Location:om.php");
exit;
