<?php
require 'db.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fecha = $_POST['fecha'] ?? '';
    $tipo = $_POST['tipo'] ?? '';
    $producto = trim($_POST['producto'] ?? '');
    $cantidad = $_POST['cantidad'] ?? '';
    $motivo = trim($_POST['motivo'] ?? '');
    $usuario = trim($_POST['usuario'] ?? '');

    if (!$fecha) $errors[] = "La fecha es obligatoria.";
    if (!$tipo) $errors[] = "El tipo de movimiento es obligatorio.";
    if ($producto === '') $errors[] = "El producto es obligatorio.";
    if ($cantidad === '' || !is_numeric($cantidad)) $errors[] = "La cantidad es obligatoria y numérica.";
    if ($motivo === '') $errors[] = "El motivo es obligatorio.";
    if ($usuario === '') $errors[] = "El usuario es obligatorio.";

    $check = $pdo->prepare("SELECT id_productos FROM productos WHERE nombre = ?");
    $check->execute([$producto]);
    if ($check->rowCount() === 0) $errors[] = "El producto '$producto' NO existe en el inventario.";

    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO otros_movimientos (fecha, tipo, producto, cantidad, motivo, usuario)
                               VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$fecha, $tipo, $producto, (int)$cantidad, $motivo, $usuario]);
        header("Location: index.php");
        exit;
    }
}
?>

<?php if (!empty($errors)): ?>
    <div style="background:#ffe1e1;padding:15px;border-radius:10px;margin-bottom:15px;">
        <?php foreach ($errors as $e): ?>
            <div style="color:#bb1a1a;font-weight:600;margin-bottom:4px;"><?= htmlspecialchars($e) ?></div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<form method="post">
    <label>Fecha</label>
    <input type="date" name="fecha" required value="<?= htmlspecialchars($_POST['fecha'] ?? '') ?>">

    <label>Tipo de movimiento</label>
    <select name="tipo" required>
        <option value="">-- Selecciona --</option>
        <?php foreach (['Ingreso','Devolución','Ajuste','Merma'] as $t): ?>
            <option value="<?= $t ?>" <?= (($_POST['tipo'] ?? '') === $t) ? 'selected' : '' ?>><?= $t ?></option>
        <?php endforeach; ?>
    </select>

    <label>Producto</label>
    <input type="text" name="producto" id="producto" autocomplete="off" placeholder="Escribe el nombre del producto" required value="<?= htmlspecialchars($_POST['producto'] ?? '') ?>">
    <div id="sugerencias" style="position:absolute; background:#fff; width:330px; max-height:180px; overflow-y:auto; border:1px solid #ccc; border-radius:10px; display:none; z-index:999;"></div>

    <label>Cantidad</label>
    <input type="number" name="cantidad" required value="<?= htmlspecialchars($_POST['cantidad'] ?? '') ?>">

    <label>Motivo</label>
    <input type="text" name="motivo" required value="<?= htmlspecialchars($_POST['motivo'] ?? '') ?>">

    <label>Usuario</label>
    <input type="text" name="usuario" required value="<?= htmlspecialchars($_POST['usuario'] ?? '') ?>">

    <div style="margin-top:12px;">
        <button class="btn-primary">Guardar</button>
        <a href="index.php" class="btn-secondary">Cancelar</a>
    </div>
</form>

<script>
const input = document.getElementById("producto");
const box = document.getElementById("sugerencias");

input.addEventListener("input", () => {
    const texto = input.value.trim();
    if (texto.length < 1) { box.style.display = "none"; return; }

    fetch("buscar_producto.php?q=" + texto)
        .then(r => r.json())
        .then(lista => {
            if (lista.length === 0) { box.style.display = "none"; return; }
            box.innerHTML = "";
            lista.forEach(p => {
                const div = document.createElement("div");
                div.textContent = p;
                div.style.padding = "10px";
                div.style.cursor = "pointer";
                div.addEventListener("click", () => { input.value = p; box.style.display = "none"; });
                box.appendChild(div);
            });
            const rect = input.getBoundingClientRect();
            box.style.position = "absolute";
            box.style.top = (input.offsetTop + input.offsetHeight) + "px";
            box.style.left = input.offsetLeft + "px";
            box.style.display = "block";
        });
});
</script>
