<?php
require 'db.php';

$q = $_GET['q'] ?? '';

$stmt = $pdo->prepare("SELECT nombre FROM productos WHERE nombre LIKE ? LIMIT 10");
$stmt->execute(["%$q%"]);

echo json_encode($stmt->fetchAll(PDO::FETCH_COLUMN));
