-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 23, 2026 at 08:34 PM
-- Server version: 11.8.6-MariaDB-log
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u102381755_sistemaInve`
--

-- --------------------------------------------------------

--
-- Table structure for table `clientes`
--

CREATE TABLE `clientes` (
  `id_clientes` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `direccion` varchar(250) DEFAULT NULL,
  `ciudad` varchar(100) DEFAULT NULL,
  `estado` varchar(100) DEFAULT NULL,
  `codigo_postal` varchar(45) DEFAULT NULL,
  `fecha_registro` date DEFAULT NULL,
  `estatus` enum('Activo','Inactivo') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `clientes`
--

INSERT INTO `clientes` (`id_clientes`, `nombre`, `email`, `telefono`, `direccion`, `ciudad`, `estado`, `codigo_postal`, `fecha_registro`, `estatus`) VALUES
(1, 'CLIENTE GENERAL', 'dgdgg', '4931949370', 'dgdg', 'dgdgf', 'fgfgdfg', '99050', '2025-11-19', 'Activo'),
(2, 'Pablo', 'cliente1@correo.com', '5561817884', 'Calle 194 #987', 'Chihuahua', 'Quintana Roo', '45751', '2024-08-07', 'Activo'),
(5, 'Lucía Díaz', 'cliente4@correo.com', '5590410901', 'Calle 43 #432', 'Puebla', 'Puebla', '34772', '2024-08-01', 'Inactivo'),
(7, 'Pedro Torres', 'cliente6@correo.com', '5570087852', 'Calle 149 #491', 'Chihuahua', 'Chihuahua', '97471', '2024-01-12', 'Inactivo'),
(8, 'Camila Díaz', 'cliente7@correo.com', '5575510615', 'Calle 40 #957', 'CDMX', 'Yucatán', '76595', '2024-02-28', 'Inactivo'),
(10, 'Pedro Hernández', 'cliente9@correo.com', '5526444874', 'Calle 139 #372', 'León', 'Nuevo León', '36213', '2024-02-21', 'Activo'),
(11, 'Fernando Ramírez', 'cliente10@correo.com', '5593839948', 'Calle 177 #350', 'Tijuana', 'CDMX', '18573', '2024-08-15', 'Activo'),
(12, 'Fernando Hernández', 'cliente11@correo.com', '5513791288', 'Calle 69 #267', 'Chihuahua', 'Nuevo León', '26599', '2024-02-28', 'Activo'),
(14, 'Jorge Díaz', 'cliente13@correo.com', '5538188033', 'Calle 134 #871', 'Chihuahua', 'Jalisco', '78340', '2024-06-03', 'Inactivo'),
(15, 'Pedro Hernández', 'cliente14@correo.com', '5590206848', 'Calle 48 #851', 'CDMX', 'CDMX', '48533', '2024-10-02', 'Inactivo'),
(16, 'María Pérez', 'cliente15@correo.com', '5557227791', 'Calle 154 #836', 'Chihuahua', 'Jalisco', '50242', '2024-05-17', 'Activo'),
(17, 'Camila Castro', 'cliente16@correo.com', '5553428267', 'Calle 60 #639', 'Chihuahua', 'Quintana Roo', '37064', '2024-08-13', 'Inactivo'),
(18, 'Jorge Sánchez', 'cliente17@correo.com', '5525030766', 'Calle 32 #716', 'Cancún', 'Chihuahua', '76860', '2024-04-05', 'Inactivo'),
(19, 'Jorge Sánchez', 'cliente18@correo.com', '5596093730', 'Calle 142 #723', 'CDMX', 'Guanajuato', '88677', '2024-08-14', 'Activo'),
(20, 'Fernando Ramírez', 'cliente19@correo.com', '5519942307', 'Calle 44 #404', 'Tijuana', 'CDMX', '21153', '2024-08-22', 'Activo'),
(21, 'Miguel Torres', 'cliente20@correo.com', '5593057117', 'Calle 176 #436', 'Guadalajara', 'CDMX', '43915', '2024-10-19', 'Activo'),
(22, 'Carlos Hernández', 'cliente21@correo.com', '5570109621', 'Calle 158 #552', 'Puebla', 'Nuevo León', '90391', '2024-10-05', 'Activo'),
(24, 'Jorge Martínez', 'cliente23@correo.com', '5551886476', 'Calle 182 #34', 'Puebla', 'Querétaro', '99953', '2024-04-19', 'Inactivo'),
(25, 'Ana Gómez', 'cliente24@correo.com', '5522335786', 'Calle 57 #981', 'Puebla', 'Quintana Roo', '84937', '2024-08-26', 'Inactivo'),
(26, 'Sofía Torres', 'cliente25@correo.com', '5515616153', 'Calle 37 #81', 'Monterrey', 'Yucatán', '46212', '2024-05-02', 'Inactivo'),
(27, 'Sofía Díaz', 'cliente26@correo.com', '5524397030', 'Calle 50 #295', 'Monterrey', 'Puebla', '28209', '2024-03-28', 'Activo'),
(28, 'Lucía Díaz', 'cliente27@correo.com', '5585489798', 'Calle 39 #793', 'Cancún', 'Baja California', '93875', '2024-02-24', 'Activo'),
(29, 'Camila Gómez', 'cliente28@correo.com', '5546737927', 'Calle 103 #831', 'Mérida', 'Puebla', '41221', '2024-02-02', 'Activo'),
(30, 'Luis Torres', 'cliente29@correo.com', '5584480742', 'Calle 116 #580', 'Querétaro', 'Baja California', '32127', '2024-09-08', 'Activo'),
(31, 'Pedro Ramírez', 'cliente30@correo.com', '5594132698', 'Calle 94 #897', 'Mérida', 'Puebla', '33214', '2024-07-26', 'Inactivo'),
(32, 'Valeria Martínez', 'cliente31@correo.com', '5557149188', 'Calle 98 #44', 'Monterrey', 'Guanajuato', '53393', '2024-06-01', 'Inactivo'),
(33, 'Miguel Sánchez', 'cliente32@correo.com', '5590142344', 'Calle 145 #447', 'CDMX', 'Querétaro', '75759', '2024-01-20', 'Activo'),
(34, 'Lucía López', 'cliente33@correo.com', '5568076604', 'Calle 64 #676', 'Puebla', 'Quintana Roo', '90395', '2024-01-10', 'Activo'),
(35, 'Juan Castro', 'cliente34@correo.com', '5532849839', 'Calle 177 #38', 'León', 'Yucatán', '17507', '2024-09-26', 'Inactivo'),
(36, 'Luis Torres', 'cliente35@correo.com', '5563463468', 'Calle 12 #524', 'Chihuahua', 'Yucatán', '94357', '2024-06-04', 'Inactivo'),
(37, 'Pedro Hernández', 'cliente36@correo.com', '5512176229', 'Calle 125 #576', 'Chihuahua', 'Jalisco', '49611', '2024-10-01', 'Inactivo'),
(38, 'Luis Hernández', 'cliente37@correo.com', '5543647697', 'Calle 73 #993', 'Monterrey', 'CDMX', '76676', '2024-09-22', 'Inactivo'),
(39, 'Fernando Castro', 'cliente38@correo.com', '5591397661', 'Calle 159 #334', 'Guadalajara', 'Puebla', '50867', '2024-10-13', 'Activo'),
(40, 'Juan Hernández', 'cliente39@correo.com', '5564236431', 'Calle 50 #790', 'Puebla', 'Quintana Roo', '88678', '2024-04-22', 'Activo'),
(41, 'Lucía Díaz', 'cliente40@correo.com', '5593186356', 'Calle 129 #598', 'León', 'Nuevo León', '38144', '2024-06-07', 'Inactivo'),
(42, 'Camila Gómez', 'cliente41@correo.com', '5573711632', 'Calle 102 #705', 'León', 'Quintana Roo', '50080', '2024-02-11', 'Activo'),
(44, 'Jorge Torres', 'cliente43@correo.com', '5511687045', 'Calle 55 #413', 'Puebla', 'Quintana Roo', '42333', '2024-09-26', 'Inactivo'),
(45, 'Pedro Hernández', 'cliente44@correo.com', '5514815649', 'Calle 38 #350', 'Guadalajara', 'Jalisco', '48441', '2024-03-26', 'Activo'),
(46, 'Fernando Gómez', 'cliente45@correo.com', '5571281071', 'Calle 59 #55', 'Monterrey', 'Quintana Roo', '81536', '2024-01-14', 'Inactivo'),
(47, 'Andrés Torres', 'cliente46@correo.com', '5574962197', 'Calle 100 #458', 'Cancún', 'Guanajuato', '90771', '2024-05-28', 'Inactivo'),
(48, 'Juan Martínez', 'cliente47@correo.com', '5512833973', 'Calle 146 #179', 'Cancún', 'Chihuahua', '87133', '2024-01-03', 'Activo'),
(49, 'Jorge Pérez', 'cliente48@correo.com', '5571474714', 'Calle 122 #600', 'Monterrey', 'Jalisco', '15869', '2024-08-14', 'Inactivo'),
(50, 'Camila Ramírez', 'cliente49@correo.com', '5558237798', 'Calle 25 #587', 'Cancún', 'Querétaro', '66523', '2024-04-15', 'Activo'),
(51, 'Luis Sánchez', 'cliente50@correo.com', '5586333119', 'Calle 125 #222', 'Puebla', 'Jalisco', '80363', '2024-02-01', 'Activo'),
(52, 'Andrés Martínez', 'cliente51@correo.com', '5512810528', 'Calle 140 #117', 'León', 'CDMX', '17528', '2024-05-06', 'Inactivo'),
(53, 'Sofía López', 'cliente52@correo.com', '5534746885', 'Calle 99 #143', 'Tijuana', 'CDMX', '52633', '2024-09-02', 'Activo'),
(54, 'Jorge Hernández', 'cliente53@correo.com', '5542741607', 'Calle 134 #816', 'León', 'Quintana Roo', '52849', '2024-04-27', 'Inactivo'),
(55, 'Sofía Torres', 'cliente54@correo.com', '5555611582', 'Calle 158 #64', 'Cancún', 'Baja California', '85907', '2024-05-07', 'Inactivo'),
(56, 'Juan Gómez', 'cliente55@correo.com', '5511599627', 'Calle 56 #808', 'Tijuana', 'Querétaro', '66392', '2024-10-24', 'Activo'),
(57, 'Andrés Martínez', 'cliente56@correo.com', '5576731492', 'Calle 139 #20', 'Guadalajara', 'Chihuahua', '96524', '2024-05-14', 'Activo'),
(58, 'Valeria Torres', 'cliente57@correo.com', '5559380196', 'Calle 96 #521', 'Mérida', 'Jalisco', '91130', '2024-05-11', 'Activo'),
(59, 'Sofía Díaz', 'cliente58@correo.com', '5538789929', 'Calle 51 #458', 'Chihuahua', 'Yucatán', '92920', '2024-03-23', 'Activo'),
(60, 'Ana Pérez', 'cliente59@correo.com', '5551718029', 'Calle 50 #60', 'Monterrey', 'Querétaro', '42613', '2024-02-16', 'Inactivo'),
(61, 'Fernando Hernández', 'cliente60@correo.com', '5513350099', 'Calle 97 #800', 'CDMX', 'Puebla', '91682', '2024-08-03', 'Inactivo'),
(62, 'Pedro Sánchez', 'cliente61@correo.com', '5522542581', 'Calle 111 #836', 'León', 'Quintana Roo', '40390', '2024-01-20', 'Activo'),
(63, 'Paula López', 'cliente62@correo.com', '5599299190', 'Calle 75 #228', 'Cancún', 'Puebla', '17264', '2024-01-17', 'Inactivo'),
(64, 'Sofía Martínez', 'cliente63@correo.com', '5531278521', 'Calle 198 #203', 'Chihuahua', 'CDMX', '90673', '2024-02-20', 'Inactivo'),
(65, 'Pedro Sánchez', 'cliente64@correo.com', '5585159855', 'Calle 143 #38', 'Querétaro', 'Chihuahua', '40811', '2024-07-09', 'Activo'),
(66, 'Valeria López', 'cliente65@correo.com', '5590233727', 'Calle 146 #693', 'Mérida', 'Quintana Roo', '81432', '2024-06-13', 'Inactivo'),
(67, 'Sofía Ramírez', 'cliente66@correo.com', '5540418298', 'Calle 160 #883', 'Cancún', 'Nuevo León', '27777', '2024-07-18', 'Inactivo'),
(68, 'Pedro Torres', 'cliente67@correo.com', '5518035515', 'Calle 162 #54', 'CDMX', 'Quintana Roo', '18867', '2024-03-22', 'Activo'),
(69, 'Andrés López', 'cliente68@correo.com', '5592950490', 'Calle 2 #48', 'Mérida', 'CDMX', '19885', '2024-08-29', 'Activo'),
(70, 'Lucía Pérez', 'cliente69@correo.com', '5577142438', 'Calle 109 #150', 'Guadalajara', 'Nuevo León', '14639', '2024-08-26', 'Inactivo'),
(71, 'Luis Pérez', 'cliente70@correo.com', '5524788199', 'Calle 128 #202', 'Querétaro', 'Chihuahua', '32909', '2024-10-04', 'Inactivo'),
(72, 'Luis Castro', 'cliente71@correo.com', '5579935363', 'Calle 154 #947', 'León', 'Jalisco', '29588', '2024-10-25', 'Inactivo'),
(73, 'Ana Hernández', 'cliente72@correo.com', '5598428995', 'Calle 67 #260', 'Monterrey', 'Quintana Roo', '61331', '2024-06-27', 'Activo'),
(74, 'Sofía Pérez', 'cliente73@correo.com', '5523459029', 'Calle 143 #375', 'CDMX', 'Quintana Roo', '37328', '2024-09-21', 'Inactivo'),
(75, 'Jorge Hernández', 'cliente74@correo.com', '5525560308', 'Calle 154 #527', 'Puebla', 'Nuevo León', '50879', '2024-01-02', 'Inactivo'),
(76, 'Luis Martínez', 'cliente75@correo.com', '5558247620', 'Calle 150 #96', 'Cancún', 'Yucatán', '66739', '2024-08-18', 'Inactivo'),
(77, 'Jorge Torres', 'cliente76@correo.com', '5592458349', 'Calle 126 #382', 'Guadalajara', 'Querétaro', '71882', '2024-04-25', 'Inactivo'),
(78, 'Lucía Castro', 'cliente77@correo.com', '5565610503', 'Calle 104 #838', 'Cancún', 'Querétaro', '23746', '2024-02-06', 'Activo'),
(79, 'Paula Martínez', 'cliente78@correo.com', '5562962263', 'Calle 99 #151', 'Mérida', 'Chihuahua', '76972', '2024-02-05', 'Activo'),
(80, 'Jorge Sánchez', 'cliente79@correo.com', '5572017149', 'Calle 28 #770', 'Guadalajara', 'Guanajuato', '47160', '2024-06-24', 'Inactivo'),
(81, 'Luis Díaz', 'cliente80@correo.com', '5596627561', 'Calle 69 #91', 'Cancún', 'Guanajuato', '95503', '2024-08-17', 'Activo'),
(82, 'Jorge Pérez', 'cliente81@correo.com', '5559471629', 'Calle 170 #999', 'CDMX', 'Querétaro', '49561', '2024-07-12', 'Inactivo'),
(83, 'Camila Gómez', 'cliente82@correo.com', '5583153693', 'Calle 115 #253', 'Chihuahua', 'Baja California', '17814', '2024-01-20', 'Activo'),
(84, 'Sofía Martínez', 'cliente83@correo.com', '5583480170', 'Calle 61 #452', 'León', 'Baja California', '36227', '2024-10-05', 'Inactivo'),
(85, 'Juan López', 'cliente84@correo.com', '5583083954', 'Calle 17 #957', 'Tijuana', 'Baja California', '81125', '2024-03-12', 'Activo'),
(86, 'Andrés Castro', 'cliente85@correo.com', '5592387785', 'Calle 12 #775', 'Cancún', 'Nuevo León', '85846', '2024-10-20', 'Activo'),
(87, 'Andrés Sánchez', 'cliente86@correo.com', '5599651216', 'Calle 164 #286', 'León', 'Nuevo León', '79071', '2024-07-06', 'Activo'),
(88, 'Pedro Martínez', 'cliente87@correo.com', '5556690738', 'Calle 189 #87', 'Tijuana', 'Quintana Roo', '51582', '2024-08-08', 'Activo'),
(89, 'Carlos Martínez', 'cliente88@correo.com', '5589333949', 'Calle 46 #960', 'Tijuana', 'Baja California', '93839', '2024-08-07', 'Activo'),
(90, 'Juan Gómez', 'cliente89@correo.com', '5593193148', 'Calle 97 #689', 'Guadalajara', 'Baja California', '40143', '2024-06-14', 'Activo'),
(91, 'Fernando Torres', 'cliente90@correo.com', '5582043857', 'Calle 91 #188', 'Tijuana', 'Puebla', '83453', '2024-02-04', 'Inactivo'),
(92, 'Pedro Castro', 'cliente91@correo.com', '5571105873', 'Calle 125 #757', 'Mérida', 'Querétaro', '27718', '2024-07-09', 'Inactivo'),
(93, 'Sofía Torres', 'cliente92@correo.com', '5523126702', 'Calle 117 #311', 'León', 'Chihuahua', '57648', '2024-09-24', 'Activo'),
(94, 'Valeria López', 'cliente93@correo.com', '5572988861', 'Calle 47 #417', 'Monterrey', 'Puebla', '98956', '2024-09-21', 'Activo'),
(95, 'Carlos Sánchez', 'cliente94@correo.com', '5581112531', 'Calle 15 #860', 'Puebla', 'Nuevo León', '68381', '2024-07-26', 'Inactivo'),
(96, 'Miguel López', 'cliente95@correo.com', '5576417571', 'Calle 17 #683', 'León', 'Nuevo León', '38951', '2024-06-29', 'Activo'),
(97, 'Fernando Castro', 'cliente96@correo.com', '5550727563', 'Calle 85 #898', 'Guadalajara', 'Yucatán', '47680', '2024-02-06', 'Activo'),
(98, 'María Sánchez', 'cliente97@correo.com', '5575942447', 'Calle 187 #759', 'Chihuahua', 'Quintana Roo', '76068', '2024-09-17', 'Inactivo'),
(99, 'Andrés Hernández', 'cliente98@correo.com', '5511793418', 'Calle 148 #237', 'Mérida', 'Chihuahua', '92757', '2024-04-10', 'Inactivo'),
(100, 'Ana Castro', 'cliente99@correo.com', '5552199213', 'Calle 24 #645', 'Puebla', 'Querétaro', '85476', '2024-09-16', 'Inactivo'),
(101, 'Lucía Pérez', 'cliente100@correo.com', '5554089000', 'Calle 183 #103', 'Puebla', 'Querétaro', '82092', '2024-07-13', 'Inactivo'),
(102, 'Pablo', 'barcobasurero@hotmail.com', '5561817884', 'Calle 194 #987', 'Chihuahua', 'Chihuahua', '45751', '2030-01-10', 'Inactivo'),
(103, '156565', 'yomelec411@ryzid.com', '4', 'PLAN PARDILLO S/N', 'ZAC', 'ZAC', '99150', '2026-05-07', 'Activo');

-- --------------------------------------------------------

--
-- Table structure for table `compras`
--

CREATE TABLE `compras` (
  `id_compras` int(11) NOT NULL,
  `Provedores_id_provedores` int(11) NOT NULL,
  `iva` float NOT NULL,
  `total` float DEFAULT NULL,
  `fecha` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `compras`
--

INSERT INTO `compras` (`id_compras`, `Provedores_id_provedores`, `iva`, `total`, `fecha`) VALUES
(307, 12, 33888, 245688, '2024-09-21'),
(308, 93, 26144, 189544, '2025-04-20'),
(309, 100, 52350.4, 379540, '2024-06-18'),
(310, 80, 32164, 233189, '2025-12-08'),
(311, 73, 9768.8, 70823.8, '2025-11-25'),
(312, 74, 9248, 67048, '2024-06-05'),
(313, 70, 2880, 20880, '2025-10-09'),
(314, 92, 53019.2, 384389, '2024-04-18'),
(315, 10, 98932, 717257, '2025-07-27'),
(316, 10, 2833.6, 20543.6, '2025-07-02'),
(317, 37, 6529.6, 47339.6, '2025-12-02'),
(318, 61, 23279.2, 168774, '2025-12-22'),
(319, 42, 15672, 113622, '2024-05-26'),
(320, 11, 26880, 194880, '2025-10-21'),
(321, 101, 10809.6, 78369.6, '2024-03-23'),
(322, 8, 12240, 88740, '2025-09-19'),
(323, 62, 15240, 110490, '2024-11-17'),
(324, 78, 35584, 257984, '2024-12-21'),
(325, 6, 369.6, 2679.6, '2024-01-16'),
(326, 41, 33408, 242208, '2025-09-14'),
(327, 4, 2719.2, 19714.2, '2024-05-15'),
(328, 45, 40935.2, 296780, '2024-09-09'),
(329, 70, 9974.4, 72314.4, '2024-02-22'),
(330, 71, 21504, 155904, '2025-02-09'),
(331, 68, 8779.2, 63649.2, '2024-10-29'),
(332, 5, 62408, 452458, '2025-12-05'),
(333, 90, 15300.8, 110931, '2025-01-09'),
(334, 93, 1584, 11484, '2025-08-10'),
(335, 10, 784, 5684, '2025-11-06'),
(336, 95, 71979.2, 521849, '2024-06-12'),
(337, 98, 12025.6, 87185.6, '2025-06-12'),
(338, 16, 2316.8, 16796.8, '2025-08-06'),
(339, 19, 320, 2320, '2024-02-23'),
(340, 47, 28592, 207292, '2025-11-10'),
(341, 26, 1440, 10440, '2024-10-06'),
(342, 78, 30432, 220632, '2025-10-29'),
(343, 55, 25663.2, 186058, '2024-06-18'),
(344, 28, 8480, 61480, '2024-06-01'),
(345, 62, 8112, 58812, '2025-04-29'),
(346, 74, 51466.4, 373131, '2025-02-25'),
(347, 16, 22161.6, 160672, '2025-08-03'),
(348, 56, 13373.6, 96958.6, '2025-07-10'),
(349, 11, 4096, 29696, '2025-02-15'),
(350, 73, 8555.2, 62025.2, '2025-01-26'),
(351, 99, 2184, 15834, '2024-04-23'),
(352, 52, 8046.4, 58336.4, '2024-11-08'),
(353, 45, 6240, 45240, '2025-12-13'),
(354, 63, 1520, 11020, '2024-11-26'),
(355, 33, 1912, 13862, '2024-11-15'),
(356, 47, 216, 1566, '2025-01-21'),
(357, 82, 5131.2, 37201.2, '2025-05-07'),
(358, 91, 11020.8, 79900.8, '2024-08-14'),
(359, 84, 11712, 84912, '2025-11-07'),
(360, 58, 70376, 510226, '2024-08-20'),
(361, 66, 50000, 362500, '2024-04-13'),
(362, 69, 2349.6, 17034.6, '2025-12-18');

-- --------------------------------------------------------

--
-- Table structure for table `otrosmovimientos`
--

CREATE TABLE `otrosmovimientos` (
  `id_otrosMovimientos` int(11) NOT NULL,
  `Productos_id_producto` int(11) NOT NULL,
  `nombre_prod` varchar(45) DEFAULT NULL,
  `tipo_mov` varchar(45) DEFAULT NULL,
  `descripcion` varchar(250) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `usuario` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `otrosmovimientos`
--

INSERT INTO `otrosmovimientos` (`id_otrosMovimientos`, `Productos_id_producto`, `nombre_prod`, `tipo_mov`, `descripcion`, `fecha`, `cantidad`, `usuario`) VALUES
(19, 22, 'Calculadora Casio MX-12B', 'Ingreso', 'Ingreso de materiales', '2026-04-09', 5, 'Pablo '),
(21, 4, 'Teclado Mecánico Redragon', 'Ingreso', 'ajuste', '2026-04-26', 56, 'patito'),
(24, 4, 'Teclado Mecánico Redragon', 'Merma', 'HAHAJHSADCHAS', '2026-05-05', 42, 'aa_luna'),
(29, 4, 'Teclado Mecánico Redragon', 'Merma', 'guguyyugyuguhvugvuesrdytfuygihu', '2026-04-30', 72, 'Aaron Luna'),
(31, 4, 'Teclado Mecánico Redragon', 'Ingreso', 'guguyyugyuguhvugvuesrdytfuygihu', '2026-05-01', 1001, 'Aaron Luna'),
(32, 4, 'Teclado Mecánico Redragon', 'Ingreso', 'hgfd', '2026-05-07', 6, 'Aaron Luna'),
(33, 16, 'Mini Proyector Wanbo', 'Merma', 'estdryugihojpklñ', '2026-05-01', 25, 'Aaron Luna'),
(34, 15, 'Bocina JBL Flip 5', 'Ingreso', 'asdfgfsdfsdsdfsdff', '2026-05-04', 43, 'Aaron Luna'),
(35, 33, 'Filtro Regulador Koblenz', 'Ingreso', 'dfghjkl', '2026-05-23', 4, 'Aaron Luna'),
(37, 4, 'Teclado Mecánico Redragon', 'Merma', 'Devolucion', '2026-05-11', 10, 'Jonathan galvan');

-- --------------------------------------------------------

--
-- Table structure for table `productos`
--

CREATE TABLE `productos` (
  `id_productos` int(11) NOT NULL,
  `codigo_articulo` varchar(20) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `categoria` varchar(45) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `precio_compra` float DEFAULT NULL,
  `precio_venta` float DEFAULT NULL,
  `proveedor` varchar(100) DEFAULT NULL,
  `fecha_ingreso` date DEFAULT NULL,
  `ubicacion` varchar(100) DEFAULT NULL,
  `estado` enum('Disponible','Agotado','Baja') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `productos`
--

INSERT INTO `productos` (`id_productos`, `codigo_articulo`, `nombre`, `categoria`, `cantidad`, `precio_compra`, `precio_venta`, `proveedor`, `fecha_ingreso`, `ubicacion`, `estado`) VALUES
(4, 'A003%', 'Teclado Mecánico Redragon', '56465564', 1412, 450, 697, 'Redragon', '2024-11-03', 'Almacén B2', 'Disponible'),
(8, 'A007', 'USB Kingston 32GB', 'Accesorios', 565, 60, 120, 'Kingston', '2024-11-05', 'Almacén B1', 'Disponible'),
(10, 'A009', 'SSD Kingston 480GB', 'Tecnología', 326, 550, 849, 'Kingston', '2024-11-06', 'Almacén A4', 'Disponible'),
(12, 'A011', 'Cable HDMI 2m', 'Accesorios', 439, 35, 79, 'Generic', '2024-11-07', 'Almacén B4', 'Disponible'),
(13, 'A012', 'Cámara Web Logitech C270', 'Tecnología', 366, 280, 450, 'Logitech', '2024-11-08', 'Almacén A5', 'Disponible'),
(15, 'A014', 'Bocina JBL Flip 5', 'Audio', 453, 1400, 1999, 'JBL', '2024-11-09', 'Almacén B6', 'Disponible'),
(16, 'A015', 'Mini Proyector Wanbo', 'Tecnología', 290, 1500, 2199, 'Wanbo', '2024-11-09', 'Almacén C3', 'Disponible'),
(17, 'A016', 'Memoria RAM 8GB DDR4', 'Tecnología', 372, 320, 549, 'Corsair', '2024-11-10', 'Almacén A2', 'Disponible'),
(18, 'A017', 'Memoria RAM 16GB DDR4', 'Tecnología', 551, 650, 999, 'Corsair', '2024-11-10', 'Almacén A2', 'Disponible'),
(19, 'A018', 'Tablet Lenovo M10', 'Tecnología', 465, 2100, 2899, 'Lenovo', '2024-11-11', 'Almacén A6', 'Disponible'),
(20, 'A019', 'Cable USB-C 1m', 'Accesorios', 519, 20, 59, 'Generic', '2024-11-11', 'Almacén B7', 'Disponible'),
(21, 'A020', 'Power Bank 10000mAh Xiaomi', 'Tecnología', 436, 220, 450, 'Xiaomi', '2024-11-12', 'Almacén B8', 'Disponible'),
(22, 'A021', 'Calculadora Casio MX-12B', 'Oficina', 513, 90, 149, 'Casio', '2024-11-12', 'Almacén C4', 'Disponible'),
(23, 'A022', 'Regulador Forza 1200VA', 'Energía', 361, 350, 599, 'Forza', '2024-11-13', 'Almacén C5', 'Disponible'),
(24, 'A023', 'Supresor de Picos Steren', 'Energía', 565, 70, 129, 'Steren', '2024-11-13', 'Almacén C6', 'Disponible'),
(25, 'A024', 'Tinta Epson 544 Negra', 'Oficina', 490, 110, 199, 'Epson', '2024-11-14', 'Almacén C1', 'Disponible'),
(26, 'A025', 'Tinta Epson 544 Color', 'Oficina', 406, 110, 199, 'Epson', '2024-11-14', 'Almacén C1', 'Disponible'),
(27, 'A026', 'Control Xbox Series', 'Gaming', 423, 1100, 1599, 'Microsoft', '2024-11-14', 'Almacén D2', 'Disponible'),
(28, 'A027', 'Control PS5 DualSense', 'Gaming', 488, 1300, 1899, 'Sony', '2024-11-15', 'Almacén D2', 'Disponible'),
(29, 'A028', 'Disipador Cooler Master', 'Tecnología', 448, 240, 399, 'Cooler Master', '2024-11-15', 'Almacén A3', 'Disponible'),
(30, 'A029', 'Tarjeta Madre ASUS B450', 'Tecnología', 446, 1300, 1899, 'ASUS', '2024-11-15', 'Almacén A3', 'Disponible'),
(31, 'A030', 'Batería CR2032', 'Accesorios', 607, 5, 20, 'Duracell', '2024-11-16', 'Almacén B9', 'Disponible'),
(32, 'A031', 'Cargador Laptop HP 45W', 'Accesorios', 456, 180, 349, 'HP', '2024-11-16', 'Almacén B4', 'Disponible'),
(33, 'A032', 'Filtro Regulador Koblenz', 'Energía', 578, 260, 399, 'Koblenz', '2024-11-17', 'Almacén C5', 'Disponible'),
(34, 'A033', 'Bocina Bluetooth Sony XB12', 'Audio', 385, 550, 799, 'Sony', '2024-11-17', 'Almacén B6', 'Disponible'),
(35, 'A034', 'Auriculares In-Ear JBL', 'Audio', 508, 120, 249, 'JBL', '2024-11-18', 'Almacén B6', 'Disponible'),
(36, 'A035', 'Smartwatch Xiaomi Mi Band 7', 'Tecnología', 505, 650, 999, 'Xiaomi', '2024-11-18', 'Almacén A6', 'Disponible'),
(37, 'A036', 'Antena WiFi USB 600Mbps', 'Redes', 435, 90, 169, 'Generic', '2024-11-19', 'Almacén C2', 'Disponible'),
(38, 'A037', 'Proyector Epson VS250', 'Tecnología', 435, 4200, 5999, 'Epson', '2024-11-19', 'Almacén C3', 'Disponible'),
(39, 'A038', 'Disco SSD NVMe 1TB', 'Tecnología', 425, 950, 1499, 'ADATA', '2024-11-20', 'Almacén A4', 'Disponible'),
(40, 'A039', 'Teclado Inalámbrico Microsoft', 'Accesorios', 495, 240, 399, 'Microsoft', '2024-11-20', 'Almacén B2', 'Disponible'),
(41, 'A040', 'Mouse Inalámbrico Microsoft', 'Accesorios', 497, 180, 299, 'Microsoft', '2024-11-20', 'Almacén B3', 'Disponible'),
(42, 'A041', 'Cable VGA 1.5m', 'Accesorios', 472, 25, 59, 'Generic', '2024-11-21', 'Almacén B4', 'Disponible'),
(43, 'A042', 'Adaptador HDMI-VGA', 'Accesorios', 399, 40, 99, 'Generic', '2024-11-21', 'Almacén B4', 'Disponible'),
(44, 'A043', 'Extensión Eléctrica 2m', 'Energía', 583, 35, 79, 'Steren', '2024-11-21', 'Almacén C6', 'Disponible'),
(45, 'A044', 'Laptop Dell Inspiron 15', 'Tecnología', 372, 8500, 11499, 'Dell', '2024-11-22', 'Almacén A1', 'Disponible'),
(46, 'A045', 'Switch 8 Puertos TP-Link', 'Redes', 302, 240, 399, 'TP-Link', '2024-11-22', 'Almacén C2', 'Disponible'),
(47, 'A046', 'Hub USB 4 Puertos', 'Accesorios', 477, 30, 79, 'Generic', '2024-11-22', 'Almacén B1', 'Disponible'),
(48, 'A047', 'Soporte para Monitor', 'Accesorios', 429, 120, 249, 'Generic', '2024-11-23', 'Almacén B2', 'Disponible'),
(49, 'A048', 'Escritorio para PC', 'Muebles', 436, 1100, 1799, 'Office Depot', '2024-11-23', 'Almacén D1', 'Disponible'),
(50, 'A049', 'Silla Ejecutiva Negra', 'Muebles', 360, 900, 1499, 'Office Depot', '2024-11-23', 'Almacén D1', 'Disponible'),
(51, 'A050', 'Folio Bond Tamaño Carta', 'Oficina', 463, 55, 109, 'Scribe', '2024-11-24', 'Almacén C1', 'Disponible'),
(52, 'A051', 'Batería Recargable AA', 'Accesorios', 388, 20, 49, 'Energizer', '2024-11-24', 'Almacén B9', 'Disponible'),
(53, 'A052', 'Memoria MicroSD 64GB', 'Accesorios', 499, 90, 169, 'Sandisk', '2024-11-25', 'Almacén B1', 'Disponible'),
(54, 'A053', 'Memoria MicroSD 128GB', 'Accesorios', 462, 160, 299, 'Sandisk', '2024-11-25', 'Almacén B1', 'Disponible'),
(55, 'A054', 'Lámpara USB LED', 'Accesorios', 505, 15, 39, 'Generic', '2024-11-25', 'Almacén B7', 'Disponible'),
(56, 'A055', 'Laptop Lenovo ThinkPad', 'Tecnología', 540, 9800, 13499, 'Lenovo', '2024-11-25', 'Almacén A1', 'Disponible'),
(57, 'A056', 'Pad Mouse XL', 'Accesorios', 432, 50, 99, 'Generic', '2024-11-26', 'Almacén B2', 'Disponible'),
(58, 'A057', 'Micrófono USB Fifine K669', 'Audio', 308, 350, 599, 'Fifine', '2024-11-26', 'Almacén B6', 'Disponible'),
(59, 'A058', 'Webcam Full HD 1080p', 'Tecnología', 486, 200, 399, 'Generic', '2024-11-26', 'Almacén A5', 'Disponible'),
(60, 'A059', 'Proyector Mini LED', 'Tecnología', 404, 750, 1199, 'Generic', '2024-11-27', 'Almacén C3', 'Disponible'),
(61, 'A060', 'Mouse Gamer RGB', 'Gaming', 566, 120, 249, 'Redragon', '2024-11-27', 'Almacén D2', 'Disponible'),
(62, 'A061', 'Teclado Gamer RGB', 'Gaming', 466, 210, 399, 'Redragon', '2024-11-27', 'Almacén D2', 'Disponible'),
(63, 'A062', 'Bocina Portátil Bass', 'Audio', 526, 110, 199, 'Generic', '2024-11-28', 'Almacén B6', 'Disponible'),
(64, 'A063', 'Audífonos Bluetooth QCY', 'Audio', 404, 150, 299, 'QCY', '2024-11-28', 'Almacén B6', 'Disponible'),
(65, 'A064', 'Reloj Inteligente T500', 'Tecnología', 570, 180, 349, 'Generic', '2024-11-28', 'Almacén A6', 'Disponible'),
(66, 'A065', 'Case para PC ATX', 'Tecnología', 413, 550, 899, 'Game Factor', '2024-11-29', 'Almacén A3', 'Disponible'),
(67, 'A066', 'Fuente 500W Game Factor', 'Tecnología', 501, 350, 599, 'Game Factor', '2024-11-29', 'Almacén A3', 'Disponible'),
(68, 'A067', 'Extensión USB 3m', 'Accesorios', 571, 25, 59, 'Generic', '2024-11-29', 'Almacén B4', 'Disponible'),
(69, 'A068', 'Smart TV TCL 43\"', 'Tecnología', 377, 4900, 6799, 'TCL', '2024-11-30', 'Almacén A0', 'Disponible'),
(70, 'A069', 'Laptop Acer Aspire 3', 'Tecnología', 457, 7200, 9999, 'Acer', '2024-11-30', 'Almacén A1', 'Disponible'),
(71, 'A070', 'Memoria USB 128GB', 'Accesorios', 357, 110, 199, 'Kingston', '2024-11-30', 'Almacén B1', 'Disponible'),
(72, 'A071', 'Router ASUS RT-AX55', 'Redes', 306, 1300, 1999, 'ASUS', '2024-12-01', 'Almacén C2', 'Disponible'),
(73, 'A072', 'Hub USB-C 6 en 1', 'Accesorios', 413, 210, 399, 'Ugreen', '2024-12-01', 'Almacén B1', 'Disponible'),
(74, 'A073', 'Disco Externo 2TB WD', 'Tecnología', 380, 1200, 1899, 'Western Digital', '2024-12-01', 'Almacén A4', 'Disponible'),
(75, 'A074', 'Audífonos Gamer Onikuma', 'Gaming', 423, 180, 349, 'Onikuma', '2024-12-02', 'Almacén D2', 'Disponible'),
(76, 'A075', 'Laptop MSI GF63', 'Tecnología', 439, 12800, 16999, 'MSI', '2024-12-02', 'Almacén A1', 'Disponible'),
(77, 'A076', 'Multímetro Digital', 'Herramientas', 491, 80, 149, 'Steren', '2024-12-02', 'Almacén C7', 'Disponible'),
(78, 'A077', 'Cámara IP Wifi 360°', 'Seguridad', 430, 280, 499, 'Ezviz', '2024-12-03', 'Almacén C8', 'Disponible'),
(79, 'A078', 'Kit Herramientas PC', 'Herramientas', 451, 180, 329, 'Generic', '2024-12-03', 'Almacén C7', 'Disponible'),
(80, 'A079', 'Soporte Laptop Ajustable', 'Accesorios', 352, 70, 149, 'Generic', '2024-12-03', 'Almacén B2', 'Disponible'),
(81, 'A080', 'Mini Bocina LED', 'Audio', 412, 45, 99, 'Generic', '2024-12-04', 'Almacén B6', 'Disponible'),
(82, 'A081', 'Cámara Deportiva 4K', 'Tecnología', 462, 400, 699, 'Generic', '2024-12-04', 'Almacén A5', 'Disponible'),
(83, 'A082', 'Foco Inteligente WiFi', 'Hogar', 432, 90, 169, 'Tuya', '2024-12-04', 'Almacén C9', 'Disponible'),
(84, 'A083', 'Interfaz de Audio USB', 'Audio', 473, 850, 1299, 'Behringer', '2024-12-05', 'Almacén B6', 'Disponible'),
(85, 'A084', 'Tripié para Celular', 'Accesorios', 411, 45, 99, 'Generic', '2024-12-05', 'Almacén B7', 'Disponible'),
(86, 'A085', 'Micrófono Lavalier', 'Audio', 377, 30, 89, 'Generic', '2024-12-06', 'Almacén B6', 'Disponible'),
(87, 'A086', 'Monitor LG 27\" IPS', 'Tecnología', 484, 3200, 4499, 'LG', '2024-12-06', 'Almacén A2', 'Disponible'),
(88, 'A087', 'Switch 16 Puertos', 'Redes', 410, 850, 1299, 'TP-Link', '2024-12-06', 'Almacén C2', 'Disponible'),
(89, 'A088', 'Cable DisplayPort 2m', 'Accesorios', 578, 45, 99, 'Generic', '2024-12-07', 'Almacén B4', 'Disponible'),
(90, 'A089', 'Cargador Rápido 25W', 'Accesorios', 384, 80, 149, 'Samsung', '2024-12-07', 'Almacén B1', 'Disponible'),
(91, 'A090', 'Tablet Samsung A8', 'Tecnología', 330, 3200, 4499, 'Samsung', '2024-12-07', 'Almacén A6', 'Disponible'),
(92, 'A091', 'Router Huawei AX3', 'Redes', 443, 850, 1299, 'Huawei', '2024-12-08', 'Almacén C2', 'Disponible'),
(94, 'A093', 'Teclado Bluetooth', 'Accesorios', 445, 110, 199, 'Logitech', '2024-12-08', 'Almacén B2', 'Disponible'),
(95, 'A094', 'Silla Gamer Razer', 'Muebles', 356, 4200, 5999, 'Razer', '2024-12-09', 'Almacén D1', 'Disponible'),
(96, 'A095', 'Laptop ASUS Vivobook', 'Tecnología', 447, 8900, 11999, 'ASUS', '2024-12-09', 'Almacén A1', 'Disponible'),
(97, 'A096', 'SSD M.2 SATA 240GB', 'Tecnología', 539, 210, 399, 'ADATA', '2024-12-09', 'Almacén A4', 'Disponible'),
(98, 'A097', 'Cámara PTZ 1080p', 'Seguridad', 417, 450, 799, 'Ezviz', '2024-12-10', 'Almacén C8', 'Disponible'),
(99, 'A098', 'Mini UPS para Modem', 'Energía', 421, 250, 449, 'CyberPower', '2024-12-10', 'Almacén C6', 'Disponible'),
(100, 'A099', 'Estuche para Laptop 15\"', 'Accesorios', 447, 70, 149, 'Generic', '2024-12-10', 'Almacén B2', 'Disponible'),
(105, 'TEC001', 'Mouse Gamer Logitech G203', 'Tecnología', 795, 250, 399, 'Logitech', '2025-01-01', 'Almacén A1', 'Disponible'),
(106, 'TEC002', 'Mouse Gamer Razer DeathAdder', 'Tecnología', 668, 400, 699, 'Razer', '2025-01-01', 'Almacén A2', 'Disponible'),
(107, 'TEC003', 'Mouse Inalámbrico HP X200', 'Tecnología', 710, 150, 299, 'HP', '2025-01-01', 'Almacén A3', 'Disponible'),
(108, 'TEC004', 'Teclado Mecánico Redragon K552', 'Tecnología', 791, 450, 799, 'Redragon', '2025-01-01', 'Almacén A4', 'Disponible'),
(109, 'TEC005', 'Teclado Inalámbrico Logitech K380', 'Tecnología', 755, 300, 599, 'Logitech', '2025-01-01', 'Almacén A5', 'Disponible'),
(110, 'TEC006', 'Monitor Samsung 24 pulgadas', 'Tecnología', 770, 2200, 2999, 'Samsung', '2025-01-01', 'Almacén A6', 'Disponible'),
(111, 'TEC007', 'Monitor LG UltraWide 29 pulgadas', 'Tecnología', 844, 3500, 4999, 'LG', '2025-01-01', 'Almacén B1', 'Disponible'),
(112, 'TEC008', 'Laptop HP Pavilion 15', 'Tecnología', 702, 8500, 11999, 'HP', '2025-01-01', 'Almacén B2', 'Disponible'),
(113, 'TEC009', 'Laptop Lenovo IdeaPad 3', 'Tecnología', 772, 7500, 10500, 'Lenovo', '2025-01-01', 'Almacén B3', 'Disponible'),
(114, 'TEC010', 'Audífonos Bluetooth Sony WH-CH510', 'Tecnología', 693, 700, 1099, 'Sony', '2025-01-01', 'Almacén B4', 'Disponible'),
(115, 'TEC011', 'Bocina JBL Flip 5', 'Tecnología', 829, 1400, 1999, 'JBL', '2025-01-01', 'Almacén B5', 'Disponible'),
(116, 'TEC012', 'SSD Kingston 480GB', 'Tecnología', 773, 550, 849, 'Kingston', '2025-01-01', 'Almacén B6', 'Disponible'),
(117, 'TEC013', 'SSD Samsung 1TB', 'Tecnología', 663, 1200, 1899, 'Samsung', '2025-01-01', 'Almacén C1', 'Disponible'),
(118, 'TEC014', 'Disco Duro Seagate 1TB', 'Tecnología', 756, 650, 999, 'Seagate', '2025-01-01', 'Almacén C2', 'Disponible'),
(119, 'TEC015', 'Disco Duro WD 2TB', 'Tecnología', 793, 900, 1399, 'Western Digital', '2025-01-01', 'Almacén C3', 'Disponible'),
(120, 'TEC016', 'Memoria RAM Corsair 8GB DDR4', 'Tecnología', 690, 320, 549, 'Corsair', '2025-01-01', 'Almacén C4', 'Disponible'),
(121, 'TEC017', 'Memoria RAM Kingston 16GB DDR4', 'Tecnología', 691, 650, 999, 'Kingston', '2025-01-01', 'Almacén C5', 'Disponible'),
(122, 'TEC018', 'Webcam Logitech C270', 'Tecnología', 817, 280, 450, 'Logitech', '2025-01-01', 'Almacén C6', 'Disponible'),
(123, 'TEC019', 'Router TP-Link AC1200', 'Tecnología', 813, 430, 699, 'TP-Link', '2025-01-01', 'Almacén A1', 'Disponible'),
(124, 'TEC020', 'Router Asus Dual Band', 'Tecnología', 647, 800, 1299, 'Asus', '2025-01-01', 'Almacén A2', 'Disponible'),
(125, 'TEC021', 'Tarjeta Gráfica Nvidia RTX 3060', 'Tecnología', 758, 7000, 9500, 'Nvidia', '2025-01-01', 'Almacén A3', 'Disponible'),
(126, 'TEC022', 'Tarjeta Gráfica AMD RX 6600', 'Tecnología', 701, 6500, 9000, 'AMD', '2025-01-01', 'Almacén A4', 'Disponible'),
(127, 'TEC023', 'Fuente de Poder EVGA 600W', 'Tecnología', 835, 800, 1200, 'EVGA', '2025-01-01', 'Almacén A5', 'Disponible'),
(128, 'TEC024', 'Gabinete Gamer NZXT H510', 'Tecnología', 871, 1500, 2200, 'NZXT', '2025-01-01', 'Almacén A6', 'Disponible'),
(129, 'TEC025', 'Tablet Samsung Galaxy Tab A', 'Tecnologíasssssssssssss', 720, 4000, 5999, 'Samsung', '2025-01-01', 'Almacén B1', 'Disponible'),
(130, 'TEC026', 'Smartwatch Huawei Watch Fit', 'Tecnología', 741, 1500, 2499, 'Huawei', '2025-01-01', 'Almacén B2', 'Disponible'),
(131, 'TEC027', 'Cable HDMI 2 metros', 'Tecnología', 824, 35, 79, 'Generic', '2025-01-01', 'Almacén B3', 'Disponible'),
(132, 'TEC028', 'Cable USB-C 1 metro', 'Tecnología', 690, 20, 59, 'Generic', '2025-01-01', 'Almacén B4', 'Disponible'),
(133, 'TEC029', 'Adaptador USB a HDMI', 'Tecnología', 708, 150, 299, 'Generic', '2025-01-01', 'Almacén B5', 'Disponible'),
(134, 'TEC030', 'Hub USB 4 puertos', 'Tecnología', 688, 120, 249, 'Generic', '2025-01-01', 'Almacén B6', 'Disponible'),
(135, 'TEC031', 'Enfriamiento Líquido Corsair H60', 'Tecnología', 789, 1200, 1800, 'Corsair', '2025-01-01', 'Almacén C1', 'Disponible'),
(136, 'TEC032', 'Ventilador PC Cooler Master', 'Tecnología', 883, 200, 399, 'Cooler Master', '2025-01-01', 'Almacén C2', 'Disponible'),
(137, 'TEC033', 'Mouse Gamer Logitech G502', 'Tecnología', 726, 600, 999, 'Logitech', '2025-01-01', 'Almacén C3', 'Disponible'),
(138, 'TEC034', 'Teclado Mecánico Razer BlackWidow', 'Tecnología', 652, 1200, 1999, 'Razer', '2025-01-01', 'Almacén C4', 'Disponible'),
(140, 'TEC036', 'Laptop Asus TUF Gaming', 'Tecnología', 786, 12000, 16500, 'Asus', '2025-01-01', 'Almacén C6', 'Disponible'),
(141, 'TEC037', 'Audífonos HyperX Cloud II', 'Tecnología', 807, 900, 1499, 'HyperX', '2025-01-01', 'Almacén A1', 'Disponible'),
(142, 'TEC038', 'Bocina Sony SRS-XB13', 'Tecnología', 856, 800, 1299, 'Sony', '2025-01-01', 'Almacén A2', 'Disponible'),
(143, 'TEC039', 'SSD WD Blue 500GB', 'Tecnología', 649, 600, 950, 'Western Digital', '2025-01-01', 'Almacén A3', 'Disponible'),
(144, 'TEC040', 'Disco Duro Toshiba 1TB', 'Tecnología', 781, 600, 950, 'Toshiba', '2025-01-01', 'Almacén A4', 'Disponible'),
(145, 'TEC100', 'Laptop Dell Inspiron 15', 'Tecnología', 823, 9500, 13500, 'Dell', '2025-01-01', 'Almacén C6', 'Disponible'),
(149, '3e123', 'galletas', 'wqe', 4, 4, 5, '54554', '2026-04-29', 'vdfvv', 'Disponible'),
(151, 'A008', 'Cable HDMI 16m', 'Accesorios', 12, 40, 100, 'Galletas', '2026-05-12', 'Almacén A3', 'Disponible'),
(153, 'A008     $', 'Cable HDMI 166m', 'Accesorios', 234234, 23442, 23423, 'fsdfs324', '2026-05-12', 'Almacén B2', 'Disponible');

-- --------------------------------------------------------

--
-- Table structure for table `productos_compras`
--

CREATE TABLE `productos_compras` (
  `Productos_id_productos` int(11) NOT NULL,
  `Compras_id_compras` int(11) NOT NULL,
  `cantidad_pd_cp` float DEFAULT NULL,
  `precio_pd_cp` float DEFAULT NULL,
  `subtotal` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `productos_compras`
--

INSERT INTO `productos_compras` (`Productos_id_productos`, `Compras_id_compras`, `cantidad_pd_cp`, `precio_pd_cp`, `subtotal`) VALUES
(107, 307, 20, 150, 3000),
(70, 307, 29, 7200, 208800),
(135, 308, 41, 1200, 49200),
(59, 308, 46, 200, 9200),
(144, 309, 50, 600, 30000),
(37, 309, 31, 90, 2790),
(76, 309, 23, 12800, 294400),
(51, 310, 15, 55, 825),
(144, 310, 7, 600, 4200),
(69, 310, 40, 4900, 196000),
(77, 311, 23, 80, 1840),
(55, 311, 49, 15, 735),
(115, 311, 38, 1400, 53200),
(63, 311, 48, 110, 5280),
(27, 312, 43, 1100, 47300),
(62, 312, 50, 210, 10500),
(65, 313, 39, 180, 7020),
(35, 313, 44, 120, 5280),
(64, 313, 38, 150, 5700),
(84, 314, 44, 850, 37400),
(113, 314, 37, 7500, 277500),
(77, 314, 7, 80, 560),
(44, 315, 17, 35, 595),
(83, 315, 20, 90, 1800),
(56, 315, 48, 9800, 470400),
(97, 315, 43, 210, 9030),
(126, 315, 21, 6500, 136500),
(134, 316, 33, 120, 3960),
(34, 316, 25, 550, 13750),
(109, 317, 49, 300, 14700),
(25, 317, 31, 110, 3410),
(17, 317, 40, 320, 12800),
(98, 317, 22, 450, 9900),
(95, 318, 19, 4200, 79800),
(44, 318, 13, 35, 455),
(96, 318, 6, 8900, 53400),
(61, 318, 47, 120, 5640),
(59, 318, 31, 200, 6200),
(31, 319, 46, 5, 230),
(91, 319, 7, 3200, 22400),
(33, 319, 27, 260, 7020),
(72, 319, 11, 1300, 14300),
(125, 320, 24, 7000, 168000),
(33, 321, 14, 260, 3640),
(114, 321, 35, 700, 24500),
(22, 321, 31, 90, 2790),
(28, 321, 28, 1300, 36400),
(31, 321, 46, 5, 230),
(45, 322, 9, 8500, 76500),
(127, 323, 48, 800, 38400),
(23, 323, 7, 350, 2450),
(74, 323, 28, 1200, 33600),
(137, 323, 28, 600, 16800),
(136, 323, 20, 200, 4000),
(145, 324, 14, 9500, 133000),
(138, 324, 41, 1200, 49200),
(77, 324, 30, 80, 2400),
(82, 324, 36, 400, 14400),
(28, 324, 18, 1300, 23400),
(24, 325, 33, 70, 2310),
(70, 326, 29, 7200, 208800),
(44, 327, 7, 35, 245),
(136, 327, 26, 200, 5200),
(34, 327, 21, 550, 11550),
(128, 328, 36, 1500, 54000),
(145, 328, 21, 9500, 199500),
(131, 328, 37, 35, 1295),
(133, 328, 7, 150, 1050),
(128, 329, 37, 1500, 55500),
(37, 329, 40, 90, 3600),
(37, 329, 36, 90, 3240),
(78, 331, 21, 280, 5880),
(18, 331, 33, 650, 21450),
(116, 331, 42, 550, 23100),
(35, 331, 37, 120, 4440),
(131, 332, 50, 35, 1750),
(75, 332, 24, 180, 4320),
(113, 332, 49, 7500, 367500),
(40, 332, 40, 240, 9600),
(54, 332, 43, 160, 6880),
(18, 333, 36, 650, 23400),
(51, 333, 16, 55, 880),
(69, 333, 14, 4900, 68600),
(66, 334, 18, 550, 9900),
(67, 335, 14, 350, 4900),
(111, 336, 15, 3500, 52500),
(112, 336, 44, 8500, 374000),
(61, 336, 26, 120, 3120),
(66, 337, 36, 550, 19800),
(15, 337, 38, 1400, 53200),
(89, 337, 48, 45, 2160),
(51, 338, 50, 55, 2750),
(48, 338, 9, 120, 1080),
(89, 338, 8, 45, 360),
(17, 338, 12, 320, 3840),
(59, 339, 10, 200, 2000),
(76, 340, 12, 12800, 153600),
(18, 340, 34, 650, 22100),
(107, 340, 20, 150, 3000),
(41, 341, 50, 180, 9000),
(99, 342, 20, 250, 5000),
(128, 342, 16, 1500, 24000),
(87, 342, 7, 3200, 22400),
(15, 342, 10, 1400, 14000),
(82, 343, 36, 400, 14400),
(33, 343, 26, 260, 6760),
(113, 343, 11, 7500, 82500),
(111, 343, 16, 3500, 56000),
(55, 343, 49, 15, 735),
(64, 344, 38, 150, 5700),
(136, 344, 43, 200, 8600),
(119, 344, 32, 900, 28800),
(108, 344, 22, 450, 9900),
(30, 345, 39, 1300, 50700),
(113, 346, 37, 7500, 277500),
(97, 346, 18, 210, 3780),
(61, 346, 18, 120, 2160),
(128, 346, 25, 1500, 37500),
(68, 346, 29, 25, 725),
(39, 347, 45, 950, 42750),
(127, 347, 25, 800, 20000),
(22, 347, 24, 90, 2160),
(106, 347, 8, 400, 3200),
(110, 347, 32, 2200, 70400),
(119, 348, 22, 900, 19800),
(19, 348, 27, 2100, 56700),
(85, 348, 35, 45, 1575),
(99, 348, 7, 250, 1750),
(90, 348, 47, 80, 3760),
(33, 349, 50, 260, 13000),
(122, 349, 45, 280, 12600),
(29, 350, 28, 240, 6720),
(141, 350, 44, 900, 39600),
(36, 351, 21, 650, 13650),
(85, 352, 48, 45, 2160),
(135, 352, 25, 1200, 30000),
(81, 352, 24, 45, 1080),
(34, 352, 31, 550, 17050),
(128, 353, 26, 1500, 39000),
(105, 354, 38, 250, 9500),
(54, 355, 44, 160, 7040),
(90, 355, 13, 80, 1040),
(37, 355, 43, 90, 3870),
(64, 356, 9, 150, 1350),
(39, 357, 27, 950, 25650),
(133, 357, 41, 150, 6150),
(81, 357, 6, 45, 270),
(33, 358, 38, 260, 9880),
(119, 358, 22, 900, 19800),
(82, 358, 14, 400, 5600),
(129, 359, 17, 4000, 68000),
(121, 359, 8, 650, 5200),
(137, 360, 26, 600, 15600),
(105, 360, 17, 250, 4250),
(140, 360, 35, 12000, 420000),
(96, 361, 34, 8900, 302600),
(49, 361, 9, 1100, 9900),
(22, 362, 23, 90, 2070),
(131, 362, 49, 35, 1715);

-- --------------------------------------------------------

--
-- Table structure for table `provedores`
--

CREATE TABLE `provedores` (
  `id_provedores` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `rfc` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `direccion` varchar(300) DEFAULT NULL,
  `promotor` varchar(100) DEFAULT NULL,
  `estado` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `provedores`
--

INSERT INTO `provedores` (`id_provedores`, `nombre`, `rfc`, `email`, `telefono`, `direccion`, `promotor`, `estado`) VALUES
(1, 'grg', 'rgrg', 'rgr', '4931949370', 'rgr', 'rg', 1),
(2, 'egee', 'ee', 'ee@gmail.com', 'fgrgrg', 'rgreg', 'ee', 1),
(3, 'TechSolutions México', 'TSM901012ABC', 'contacto@techsolutions.mx', '5512345678', 'Av. Insurgentes Sur 123, CDMX', 'Carlos Ruiz', 1),
(4, 'Suministros Globales', 'SGL850520HGT', 'ventas@suministros.com', '8183456789', 'Calle Industrial 450, Monterrey', 'Ana Martínez', 1),
(5, 'Logística del Norte', 'LNO950130JJ1', 'info@lognor.com', '6649876543', 'Blvd. Agua Caliente 78, Tijuana', 'Luis Castro', 1),
(6, 'Importaciones Bajío', 'IBA020315K8L', 'pedidos@bajioimport.mx', '4771239876', 'Paseo del Jerez 201, León', 'Sofía Torres', 1),
(7, 'Redes y Comunicaciones ZAC', 'RCZ100822PL0', 'soporte@redeszac.com', '4931002233', 'Hidalgo 50, Fresnillo, Zacatecas', 'Jorge Aguilera', 1),
(8, 'Distribuidora Azteca', 'DAZ771105M55', 'atencion@distazteca.com', '3336781234', 'Av. Vallarta 3200, Guadalajara', 'Miguel López', 1),
(9, 'Equipos de Oficina Express', 'EOE081212QW1', 'ventas@ofiexpress.mx', '5559874123', 'Colonia Juárez 99, CDMX', 'Lucía Díaz', 1),
(10, 'Sistemas Integrales de Seguridad', 'SIS150601990', 'admin@sis-seguridad.com', '2224567890', 'Reforma 405, Puebla', 'Fernando Ramírez', 1),
(11, 'Componentes Electrónicos del Sur', 'CES050403RT4', 'ventas@compelsur.com', '9981234567', 'Av. Tulum 15, Cancún', 'Paula Martínez', 1),
(12, 'Muebles de Oficina Profesionales', 'MOP920808XYZ', 'proyectos@mueblespro.mx', '4421478520', 'Bernardo Quintana 500, Querétaro', 'Andrés Hernández', 1),
(13, 'Proveedor Automático 13', 'RFC8115ABC', 'contacto13@empresa.com', '4939473609', 'Calle Principal #13, CP 99000', 'Promotor Asignado', 1),
(14, 'Proveedor Automático 14', 'RFC4018ABC', 'contacto14@empresa.com', '4938672288', 'Calle Principal #14, CP 99000', 'Promotor Asignado', 1),
(15, 'Proveedor Automático 15', 'RFC3305ABC', 'contacto15@empresa.com', '4937511004', 'Calle Principal #15, CP 99000', 'Promotor Asignado', 1),
(16, 'Proveedor Automático 16', 'RFC8637ABC', 'contacto16@empresa.com', '4931658498', 'Calle Principal #16, CP 99000', 'Promotor Asignado', 1),
(17, 'Proveedor Automático 17', 'RFC8376ABC', 'contacto17@empresa.com', '4938912426', 'Calle Principal #17, CP 99000', 'Promotor Asignado', 1),
(18, 'Proveedor Automático 18', 'RFC9428ABC', 'contacto18@empresa.com', '4931409644', 'Calle Principal #18, CP 99000', 'Promotor Asignado', 1),
(19, 'Proveedor Automático 19', 'RFC4759ABC', 'contacto19@empresa.com', '4939571401', 'Calle Principal #19, CP 99000', 'Promotor Asignado', 1),
(20, 'Proveedor Automático 20', 'RFC5576ABC', 'contacto20@empresa.com', '4937169847', 'Calle Principal #20, CP 99000', 'Promotor Asignado', 1),
(21, 'Proveedor Automático 21', 'RFC9117ABC', 'contacto21@empresa.com', '4935084498', 'Calle Principal #21, CP 99000', 'Promotor Asignado', 1),
(22, 'Proveedor Automático 22', 'RFC6065ABC', 'contacto22@empresa.com', '4935076840', 'Calle Principal #22, CP 99000', 'Promotor Asignado', 1),
(23, 'Proveedor Automático 23', 'RFC6185ABC', 'contacto23@empresa.com', '4935699500', 'Calle Principal #23, CP 99000', 'Promotor Asignado', 1),
(24, 'Proveedor Automático 24', 'RFC8938ABC', 'contacto24@empresa.com', '4938598954', 'Calle Principal #24, CP 99000', 'Promotor Asignado', 1),
(25, 'Proveedor Automático 25', 'RFC6175ABC', 'contacto25@empresa.com', '4934084645', 'Calle Principal #25, CP 99000', 'Promotor Asignado', 1),
(26, 'Proveedor Automático 26', 'RFC9893ABC', 'contacto26@empresa.com', '4939217663', 'Calle Principal #26, CP 99000', 'Promotor Asignado', 1),
(27, 'Proveedor Automático 27', 'RFC6404ABC', 'contacto27@empresa.com', '4933373824', 'Calle Principal #27, CP 99000', 'Promotor Asignado', 1),
(28, 'Proveedor Automático 28', 'RFC5652ABC', 'contacto28@empresa.com', '4938143685', 'Calle Principal #28, CP 99000', 'Promotor Asignado', 1),
(29, 'Proveedor Automático 29', 'RFC4758ABC', 'contacto29@empresa.com', '4937365614', 'Calle Principal #29, CP 99000', 'Promotor Asignado', 1),
(30, 'Proveedor Automático 30', 'RFC3549ABC', 'contacto30@empresa.com', '4933653514', 'Calle Principal #30, CP 99000', 'Promotor Asignado', 1),
(31, 'Proveedor Automático 31', 'RFC6616ABC', 'contacto31@empresa.com', '4933126247', 'Calle Principal #31, CP 99000', 'Promotor Asignado', 1),
(32, 'Proveedor Automático 32', 'RFC3778ABC', 'contacto32@empresa.com', '4938517079', 'Calle Principal #32, CP 99000', 'Promotor Asignado', 1),
(33, 'Proveedor Automático 33', 'RFC3247ABC', 'contacto33@empresa.com', '4937688301', 'Calle Principal #33, CP 99000', 'Promotor Asignado', 1),
(34, 'Proveedor Automático 34', 'RFC9696ABC', 'contacto34@empresa.com', '4936424018', 'Calle Principal #34, CP 99000', 'Promotor Asignado', 1),
(35, 'Proveedor Automático 35', 'RFC2026ABC', 'contacto35@empresa.com', '4937861641', 'Calle Principal #35, CP 99000', 'Promotor Asignado', 1),
(36, 'Proveedor Automático 36', 'RFC5227ABC', 'contacto36@empresa.com', '4931555034', 'Calle Principal #36, CP 99000', 'Promotor Asignado', 1),
(37, 'Proveedor Automático 37', 'RFC9090ABC', 'contacto37@empresa.com', '4933790881', 'Calle Principal #37, CP 99000', 'Promotor Asignado', 1),
(38, 'Proveedor Automático 38', 'RFC8679ABC', 'contacto38@empresa.com', '4934031438', 'Calle Principal #38, CP 99000', 'Promotor Asignado', 1),
(39, 'Proveedor Automático 39', 'RFC2114ABC', 'contacto39@empresa.com', '4936479404', 'Calle Principal #39, CP 99000', 'Promotor Asignado', 1),
(40, 'Proveedor Automático 40', 'RFC7052ABC', 'contacto40@empresa.com', '4935825747', 'Calle Principal #40, CP 99000', 'Promotor Asignado', 1),
(41, 'Proveedor Automático 41', 'RFC6969ABC', 'contacto41@empresa.com', '4937374564', 'Calle Principal #41, CP 99000', 'Promotor Asignado', 1),
(42, 'Proveedor Automático 42', 'RFC5961ABC', 'contacto42@empresa.com', '4936685004', 'Calle Principal #42, CP 99000', 'Promotor Asignado', 1),
(43, 'Proveedor Automático 43', 'RFC5539ABC', 'contacto43@empresa.com', '4936644011', 'Calle Principal #43, CP 99000', 'Promotor Asignado', 1),
(44, 'Proveedor Automático 44', 'RFC6600ABC', 'contacto44@empresa.com', '4933071190', 'Calle Principal #44, CP 99000', 'Promotor Asignado', 1),
(45, 'Proveedor Automático 45', 'RFC3553ABC', 'contacto45@empresa.com', '4937556512', 'Calle Principal #45, CP 99000', 'Promotor Asignado', 1),
(46, 'Proveedor Automático 46', 'RFC8119ABC', 'contacto46@empresa.com', '4937933031', 'Calle Principal #46, CP 99000', 'Promotor Asignado', 1),
(47, 'Proveedor Automático 47', 'RFC5303ABC', 'contacto47@empresa.com', '4931718992', 'Calle Principal #47, CP 99000', 'Promotor Asignado', 1),
(48, 'Proveedor Automático 48', 'RFC9683ABC', 'contacto48@empresa.com', '4936263566', 'Calle Principal #48, CP 99000', 'Promotor Asignado', 1),
(49, 'Proveedor Automático 49', 'RFC1265ABC', 'contacto49@empresa.com', '4934536841', 'Calle Principal #49, CP 99000', 'Promotor Asignado', 1),
(50, 'Proveedor Automático 50', 'RFC8886ABC', 'contacto50@empresa.com', '4932827900', 'Calle Principal #50, CP 99000', 'Promotor Asignado', 1),
(51, 'Proveedor Automático 51', 'RFC4476ABC', 'contacto51@empresa.com', '4933898537', 'Calle Principal #51, CP 99000', 'Promotor Asignado', 1),
(52, 'Proveedor Automático 52', 'RFC5062ABC', 'contacto52@empresa.com', '4933621119', 'Calle Principal #52, CP 99000', 'Promotor Asignado', 1),
(53, 'Proveedor Automático 53', 'RFC1915ABC', 'contacto53@empresa.com', '4936714441', 'Calle Principal #53, CP 99000', 'Promotor Asignado', 1),
(54, 'Proveedor Automático 54', 'RFC8824ABC', 'contacto54@empresa.com', '4934984312', 'Calle Principal #54, CP 99000', 'Promotor Asignado', 1),
(55, 'Proveedor Automático 55', 'RFC6444ABC', 'contacto55@empresa.com', '4937271981', 'Calle Principal #55, CP 99000', 'Promotor Asignado', 1),
(56, 'Proveedor Automático 56', 'RFC7024ABC', 'contacto56@empresa.com', '4933308836', 'Calle Principal #56, CP 99000', 'Promotor Asignado', 1),
(57, 'Proveedor Automático 57', 'RFC3469ABC', 'contacto57@empresa.com', '4936420056', 'Calle Principal #57, CP 99000', 'Promotor Asignado', 1),
(58, 'Proveedor Automático 58', 'RFC2692ABC', 'contacto58@empresa.com', '4932201558', 'Calle Principal #58, CP 99000', 'Promotor Asignado', 1),
(59, 'Proveedor Automático 59', 'RFC1930ABC', 'contacto59@empresa.com', '4932049110', 'Calle Principal #59, CP 99000', 'Promotor Asignado', 1),
(60, 'Proveedor Automático 60', 'RFC3453ABC', 'contacto60@empresa.com', '4931119071', 'Calle Principal #60, CP 99000', 'Promotor Asignado', 1),
(61, 'Proveedor Automático 61', 'RFC3235ABC', 'contacto61@empresa.com', '4932820367', 'Calle Principal #61, CP 99000', 'Promotor Asignado', 1),
(62, 'Proveedor Automático 62', 'RFC3395ABC', 'contacto62@empresa.com', '4937515351', 'Calle Principal #62, CP 99000', 'Promotor Asignado', 1),
(63, 'Proveedor Automático 63', 'RFC8390ABC', 'contacto63@empresa.com', '4939408385', 'Calle Principal #63, CP 99000', 'Promotor Asignado', 1),
(64, 'Proveedor Automático 64', 'RFC2869ABC', 'contacto64@empresa.com', '4933121170', 'Calle Principal #64, CP 99000', 'Promotor Asignado', 1),
(65, 'Proveedor Automático 65', 'RFC5997ABC', 'contacto65@empresa.com', '4931626767', 'Calle Principal #65, CP 99000', 'Promotor Asignado', 1),
(66, 'Proveedor Automático 66', 'RFC7138ABC', 'contacto66@empresa.com', '4932818058', 'Calle Principal #66, CP 99000', 'Promotor Asignado', 1),
(67, 'Proveedor Automático 67', 'RFC9670ABC', 'contacto67@empresa.com', '4932902205', 'Calle Principal #67, CP 99000', 'Promotor Asignado', 1),
(68, 'Proveedor Automático 68', 'RFC2497ABC', 'contacto68@empresa.com', '4932779381', 'Calle Principal #68, CP 99000', 'Promotor Asignado', 1),
(69, 'Proveedor Automático 69', 'RFC5404ABC', 'contacto69@empresa.com', '4938688398', 'Calle Principal #69, CP 99000', 'Promotor Asignado', 1),
(70, 'Proveedor Automático 70', 'RFC8225ABC', 'contacto70@empresa.com', '4935065163', 'Calle Principal #70, CP 99000', 'Promotor Asignado', 1),
(71, 'Proveedor Automático 71', 'RFC8646ABC', 'contacto71@empresa.com', '4939042527', 'Calle Principal #71, CP 99000', 'Promotor Asignado', 1),
(72, 'Proveedor Automático 72', 'RFC9268ABC', 'contacto72@empresa.com', '4939221567', 'Calle Principal #72, CP 99000', 'Promotor Asignado', 1),
(73, 'Proveedor Automático 73', 'RFC8297ABC', 'contacto73@empresa.com', '4933827040', 'Calle Principal #73, CP 99000', 'Promotor Asignado', 1),
(74, 'Proveedor Automático 74', 'RFC2240ABC', 'contacto74@empresa.com', '4937719663', 'Calle Principal #74, CP 99000', 'Promotor Asignado', 1),
(75, 'Proveedor Automático 75', 'RFC3877ABC', 'contacto75@empresa.com', '4934230258', 'Calle Principal #75, CP 99000', 'Promotor Asignado', 1),
(76, 'Proveedor Automático 76', 'RFC8516ABC', 'contacto76@empresa.com', '4931897943', 'Calle Principal #76, CP 99000', 'Promotor Asignado', 1),
(77, 'Proveedor Automático 77', 'RFC9935ABC', 'contacto77@empresa.com', '4936988606', 'Calle Principal #77, CP 99000', 'Promotor Asignado', 1),
(78, 'Proveedor Automático 78', 'RFC4133ABC', 'contacto78@empresa.com', '4937702033', 'Calle Principal #78, CP 99000', 'Promotor Asignado', 1),
(79, 'Proveedor Automático 79', 'RFC7108ABC', 'contacto79@empresa.com', '4932441185', 'Calle Principal #79, CP 99000', 'Promotor Asignado', 1),
(80, 'Proveedor Automático 80', 'RFC7876ABC', 'contacto80@empresa.com', '4934064227', 'Calle Principal #80, CP 99000', 'Promotor Asignado', 1),
(81, 'Proveedor Automático 81', 'RFC4688ABC', 'contacto81@empresa.com', '4931249665', 'Calle Principal #81, CP 99000', 'Promotor Asignado', 1),
(82, 'Proveedor Automático 82', 'RFC9182ABC', 'contacto82@empresa.com', '4935165587', 'Calle Principal #82, CP 99000', 'Promotor Asignado', 1),
(83, 'Proveedor Automático 83', 'RFC6278ABC', 'contacto83@empresa.com', '4935899182', 'Calle Principal #83, CP 99000', 'Promotor Asignado', 1),
(84, 'Proveedor Automático 84', 'RFC9657ABC', 'contacto84@empresa.com', '4932594191', 'Calle Principal #84, CP 99000', 'Promotor Asignado', 1),
(85, 'Proveedor Automático 85', 'RFC9994ABC', 'contacto85@empresa.com', '4935197004', 'Calle Principal #85, CP 99000', 'Promotor Asignado', 1),
(86, 'Proveedor Automático 86', 'RFC3996ABC', 'contacto86@empresa.com', '4933395371', 'Calle Principal #86, CP 99000', 'Promotor Asignado', 1),
(87, 'Proveedor Automático 87', 'RFC3984ABC', 'contacto87@empresa.com', '4938739024', 'Calle Principal #87, CP 99000', 'Promotor Asignado', 1),
(88, 'Proveedor Automático 88', 'RFC3739ABC', 'contacto88@empresa.com', '4939483137', 'Calle Principal #88, CP 99000', 'Promotor Asignado', 0),
(89, 'Proveedor Automático 89', 'RFC8194ABC', 'contacto89@empresa.com', '4932528406', 'Calle Principal #89, CP 99000', 'Promotor Asignado', 1),
(90, 'Proveedor Automático 90', 'RFC5054ABC', 'contacto90@empresa.com', '4937691487', 'Calle Principal #90, CP 99000', 'Promotor Asignado', 1),
(91, 'Proveedor Automático 91', 'RFC4291ABC', 'contacto91@empresa.com', '4936382623', 'Calle Principal #91, CP 99000', 'Promotor Asignado', 1),
(92, 'Proveedor Automático 92', 'RFC9037ABC', 'contacto92@empresa.com', '4937046452', 'Calle Principal #92, CP 99000', 'Promotor Asignado', 0),
(93, 'Proveedor Automático 93', 'RFC7114ABC', 'contacto93@empresa.com', '4934439005', 'Calle Principal #93, CP 99000', 'Promotor Asignado', 0),
(94, 'Proveedor Automático 94', 'RFC8847ABC', 'contacto94@empresa.com', '4932923027', 'Calle Principal #94, CP 99000', 'Promotor Asignado', 1),
(95, 'Proveedor Automático 95', 'RFC5070ABC', 'contacto95@empresa.com', '4936586486', 'Calle Principal #95, CP 99000', 'Promotor Asignado', 1),
(96, 'Proveedor Automático 96', 'RFC7718ABC', 'contacto96@empresa.com', '4938836006', 'Calle Principal #96, CP 99000', 'Promotor Asignado', 0),
(97, 'Proveedor Automático 97', 'RFC2022ABC', 'contacto97@empresa.com', '4939605747', 'Calle Principal #97, CP 99000', 'Promotor Asignado', 1),
(98, 'Proveedor Automático 98', 'RFC4960ABC', 'contacto98@empresa.com', '4933985155', 'Calle Principal #98, CP 99000', 'Promotor Asignado', 0),
(99, 'Proveedor Automático 99', 'RFC4044ABC', 'contacto99@empresa.com', '4937266235', 'Calle Principal #99, CP 99000', 'Promotor Asignado', 1),
(100, 'Proveedor Automático 100', 'RFC5197ABC', 'contacto100@empresa.com', '4933192079', 'Calle Principal #100, CP 99000', 'Promotor Asignado', 0),
(101, 'Provveedor de llantas de tractor', 'RFC8365ABC', 'contacto101@empresa.com', '4934253387', 'huehuetoca', 'Promotor Asignado', 0),
(103, 'llantas de triciclo apache', 'ALABIOALABAO12131456', 'contacto101@empresa.com', '4934253387', 'huehuetoca', 'Promotor Asignado', 0),
(105, 'JUAN', '25454AF', 'yomelec411@ryzid.com', '4931114065', 'PLAN PARDILLO S/N', '554A', 0),
(106, '156565', '25454AF', 'mariagrm0912@gmail.com', '493', 'PLAN PARDILLO S/N', '554A', 0),
(107, '156565', '', '', '4', '', '', 0),
(108, '3235223', '25454AF', 'yomelec411@ryzid.com', '493', 'PLAN PARDILLO S/N', '', 0),
(109, 'SDFVD', '!\"#$%&/()', 'mariagrm0912@gmail.com', '4126+4565645564', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `provedores_productos`
--

CREATE TABLE `provedores_productos` (
  `Provedores_id_provedores` int(11) NOT NULL,
  `Productos_id_producto` int(11) NOT NULL,
  `Provedores_Productoscol` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `prueba`
--

CREATE TABLE `prueba` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ventas`
--

CREATE TABLE `ventas` (
  `id_ventas` int(11) NOT NULL,
  `Clientes_id_clientes` int(11) NOT NULL,
  `iva` float DEFAULT NULL,
  `total` float DEFAULT NULL,
  `fecha_venta` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ventas`
--

INSERT INTO `ventas` (`id_ventas`, `Clientes_id_clientes`, `iva`, `total`, `fecha_venta`) VALUES
(693, 1, 79.68, 577.68, '2025-02-13'),
(694, 1, 31.68, 229.68, '2024-12-20'),
(695, 1, 28.48, 206.48, '2025-07-07'),
(696, 1, 4320, 31320, '2024-12-07'),
(697, 1, 191.68, 1389.68, '2024-10-31'),
(698, 1, 54.08, 392.08, '2024-02-02'),
(699, 1, 704, 5104, '2024-06-05'),
(700, 1, 31.68, 229.68, '2025-09-20'),
(701, 1, 127.68, 925.68, '2024-10-30'),
(702, 1, 351.68, 2549.68, '2025-03-26'),
(703, 1, 319.68, 2317.68, '2024-03-30'),
(704, 1, 31.68, 229.68, '2025-07-10'),
(705, 1, 31.68, 229.68, '2025-10-29'),
(706, 1, 3839.68, 27837.7, '2025-05-06'),
(707, 1, 3040, 22040, '2025-08-11'),
(708, 1, 4320, 31320, '2025-05-09'),
(709, 1, 31.68, 229.68, '2024-06-20'),
(710, 1, 351.68, 2549.68, '2025-06-22'),
(711, 1, 95.68, 693.68, '2025-03-29'),
(712, 1, 63.68, 461.68, '2025-05-06'),
(713, 1, 304, 2204, '2024-11-19'),
(714, 1, 319.68, 2317.68, '2025-01-10'),
(715, 1, 304, 2204, '2025-09-23'),
(716, 1, 25.28, 183.28, '2024-06-02'),
(717, 1, 127.68, 925.68, '2025-10-31'),
(718, 1, 639.68, 4637.68, '2025-07-26'),
(719, 1, 799.68, 5797.68, '2024-12-06'),
(720, 1, 18.88, 136.88, '2025-12-11'),
(721, 1, 2880, 20880, '2024-05-28'),
(722, 1, 271.68, 1969.68, '2024-04-07'),
(723, 1, 639.68, 4637.68, '2024-01-01'),
(724, 1, 31.68, 229.68, '2024-08-19'),
(725, 1, 319.68, 2317.68, '2025-07-08'),
(726, 1, 63.68, 461.68, '2024-01-29'),
(727, 1, 25.28, 183.28, '2024-09-16'),
(728, 1, 79.68, 577.68, '2025-07-25'),
(729, 1, 271.68, 1969.68, '2025-06-08'),
(730, 1, 319.68, 2317.68, '2024-03-14'),
(731, 1, 3040, 22040, '2024-04-29'),
(732, 1, 255.68, 1853.68, '2024-10-06'),
(733, 1, 18.88, 136.88, '2024-08-21'),
(734, 1, 28.48, 206.48, '2024-08-21'),
(735, 1, 255.68, 1853.68, '2025-04-15'),
(736, 1, 3040, 22040, '2025-04-29'),
(737, 1, 2080, 15080, '2024-06-18'),
(738, 1, 79.68, 577.68, '2024-11-18'),
(739, 1, 704, 5104, '2025-12-03'),
(740, 1, 286.24, 2075.24, '2024-03-24'),
(741, 1, 415.68, 3013.68, '2025-10-22'),
(742, 1, 144, 1044, '2025-05-08'),
(743, 1, 1919.68, 13917.7, '2024-01-12'),
(744, 1, 111.68, 809.68, '2025-09-25'),
(745, 1, 3199.68, 23197.7, '2024-04-07'),
(746, 1, 111.68, 809.68, '2024-08-16'),
(747, 1, 3360, 24360, '2024-10-30'),
(748, 1, 191.68, 1389.68, '2025-09-24'),
(749, 1, 18.88, 136.88, '2025-04-13'),
(750, 1, 144, 1044, '2024-08-02'),
(751, 1, 3839.68, 27837.7, '2024-02-28'),
(752, 1, 95.68, 693.68, '2024-12-28'),
(753, 1, 111.68, 809.68, '2025-01-21'),
(754, 1, 2175.68, 15773.7, '2024-03-12'),
(755, 1, 63.68, 461.68, '2025-10-15'),
(756, 1, 319.68, 2317.68, '2024-03-10'),
(757, 1, 223.68, 1621.68, '2025-12-23'),
(758, 1, 1439.68, 10437.7, '2025-08-17'),
(759, 1, 639.68, 4637.68, '2025-03-02'),
(760, 1, 959.68, 6957.68, '2024-07-26'),
(761, 1, 54.08, 392.08, '2025-05-22'),
(762, 1, 319.68, 2317.68, '2025-03-06'),
(763, 1, 159.68, 1157.68, '2024-11-25'),
(764, 1, 319.68, 2317.68, '2025-02-24'),
(765, 1, 639.68, 4637.68, '2024-08-25'),
(766, 1, 959.68, 6957.68, '2024-01-19'),
(767, 1, 127.68, 925.68, '2024-04-20'),
(768, 1, 319.68, 2317.68, '2025-01-26'),
(769, 1, 415.68, 3013.68, '2024-07-27'),
(770, 1, 127.68, 925.68, '2025-09-07'),
(771, 1, 1439.68, 10437.7, '2024-05-07'),
(772, 1, 79.68, 577.68, '2024-11-20'),
(773, 1, 319.68, 2317.68, '2025-06-20'),
(774, 1, 576, 4176, '2025-01-10'),
(775, 1, 18.88, 136.88, '2024-01-05'),
(776, 1, 351.68, 2549.68, '2025-04-13'),
(777, 1, 959.68, 6957.68, '2025-11-19'),
(778, 1, 144, 1044, '2025-06-11'),
(779, 1, 2880, 20880, '2025-01-29'),
(780, 1, 63.68, 461.68, '2024-08-25'),
(781, 1, 54.08, 392.08, '2025-06-22'),
(782, 1, 18.88, 136.88, '2025-06-12'),
(783, 1, 639.68, 4637.68, '2024-08-01'),
(784, 1, 1919.68, 13917.7, '2024-10-12'),
(785, 1, 6.4, 46.4, '2025-02-26'),
(786, 1, 21.44, 155.44, '2025-11-16'),
(787, 1, 575.68, 4173.68, '2024-08-10'),
(788, 1, 79.68, 577.68, '2024-12-03'),
(789, 1, 1919.68, 13917.7, '2024-07-13'),
(790, 1, 18.88, 136.88, '2025-02-21'),
(791, 1, 144, 1044, '2024-02-20'),
(792, 1, 1919.68, 13917.7, '2024-09-29'),
(793, 1, 127.68, 925.68, '2024-03-22'),
(794, 1, 144, 1044, '2024-09-01'),
(795, 1, 4320, 31320, '2024-04-18'),
(796, 1, 18.88, 136.88, '2025-06-14'),
(797, 1, 959.68, 6957.68, '2024-03-05'),
(798, 1, 3839.68, 27837.7, '2024-08-15'),
(799, 1, 319.68, 2317.68, '2025-06-17'),
(800, 1, 127.68, 925.68, '2025-11-01'),
(801, 1, 47.68, 345.68, '2025-04-28'),
(802, 1, 576, 4176, '2024-08-19'),
(803, 1, 223.68, 1621.68, '2025-04-18'),
(804, 1, 223.68, 1621.68, '2024-07-05'),
(805, 1, 607.68, 4405.68, '2025-03-01'),
(806, 1, 127.68, 925.68, '2025-06-27'),
(807, 1, 31.68, 229.68, '2024-07-11'),
(808, 1, 415.68, 3013.68, '2025-03-31'),
(809, 1, 255.68, 1853.68, '2024-11-02'),
(810, 1, 95.68, 693.68, '2024-11-14'),
(811, 1, 271.68, 1969.68, '2024-08-27'),
(812, 1, 127.68, 925.68, '2025-10-07'),
(813, 1, 287.68, 2085.68, '2025-02-04'),
(814, 1, 111.68, 809.68, '2025-07-03'),
(815, 1, 351.68, 2549.68, '2025-09-01'),
(816, 1, 31.68, 229.68, '2025-12-29'),
(817, 1, 2080, 15080, '2024-12-03'),
(818, 1, 127.68, 925.68, '2024-05-28'),
(819, 1, 25.28, 183.28, '2025-05-06'),
(820, 1, 4319.68, 31317.7, '2024-07-07'),
(821, 1, 3679.68, 26677.7, '2024-02-06'),
(822, 1, 31.68, 229.68, '2025-09-06'),
(823, 1, 5439.68, 39437.7, '2024-11-06'),
(824, 1, 127.68, 925.68, '2024-08-10'),
(825, 1, 31.68, 229.68, '2025-08-05'),
(826, 1, 79.68, 577.68, '2024-01-30'),
(827, 1, 223.68, 1621.68, '2025-04-10'),
(828, 1, 959.68, 6957.68, '2024-07-11'),
(829, 1, 1919.68, 13917.7, '2025-09-02'),
(830, 1, 799.68, 5797.68, '2024-03-30'),
(831, 1, 111.68, 809.68, '2024-09-03'),
(833, 1, 383.68, 2781.68, '2025-10-01'),
(834, 1, 95.68, 693.68, '2025-12-16'),
(835, 1, 79.68, 577.68, '2025-10-21'),
(836, 1, 639.68, 4637.68, '2024-10-08'),
(840, 1, 18.88, 136.88, '2024-11-16');

-- --------------------------------------------------------

--
-- Table structure for table `ventas_productos`
--

CREATE TABLE `ventas_productos` (
  `Ventas_id_ventas` int(11) NOT NULL,
  `Productos_id_productos` int(11) NOT NULL,
  `cantidad` float DEFAULT NULL,
  `precio` float DEFAULT NULL,
  `subtotal` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ventas_productos`
--

INSERT INTO `ventas_productos` (`Ventas_id_ventas`, `Productos_id_productos`, `cantidad`, `precio`, `subtotal`) VALUES
(693, 134, 2, 249, 498),
(694, 81, 2, 99, 198),
(695, 86, 2, 89, 178),
(696, 145, 2, 13500, 27000),
(697, 109, 2, 599, 1198),
(698, 83, 2, 169, 338),
(699, 128, 2, 2200, 4400),
(700, 81, 2, 99, 198),
(701, 136, 2, 399, 798),
(702, 114, 2, 1099, 2198),
(703, 137, 2, 999, 1998),
(704, 57, 2, 99, 198),
(705, 81, 2, 99, 198),
(706, 112, 2, 11999, 23998),
(707, 125, 2, 9500, 19000),
(708, 145, 2, 13500, 27000),
(709, 43, 2, 99, 198),
(710, 114, 2, 1099, 2198),
(711, 133, 2, 299, 598),
(712, 25, 2, 199, 398),
(713, 144, 2, 950, 1900),
(714, 121, 2, 999, 1998),
(715, 143, 2, 950, 1900),
(716, 12, 2, 79, 158),
(717, 97, 2, 399, 798),
(718, 115, 2, 1999, 3998),
(719, 130, 2, 2499, 4998),
(720, 42, 2, 59, 118),
(721, 126, 2, 9000, 18000),
(722, 116, 2, 849, 1698),
(723, 138, 2, 1999, 3998),
(724, 81, 2, 99, 198),
(725, 121, 2, 999, 1998),
(726, 71, 2, 199, 398),
(727, 12, 2, 79, 158),
(728, 35, 2, 249, 498),
(729, 116, 2, 849, 1698),
(731, 125, 2, 9500, 19000),
(732, 108, 2, 799, 1598),
(733, 20, 2, 59, 118),
(734, 86, 2, 89, 178),
(735, 108, 2, 799, 1598),
(736, 125, 2, 9500, 19000),
(738, 35, 2, 249, 498),
(739, 128, 2, 2200, 4400),
(740, 43, 1, 99, 99),
(740, 37, 10, 169, 1690),
(741, 142, 2, 1299, 2598),
(742, 13, 2, 450, 900),
(743, 38, 2, 5999, 11998),
(744, 32, 2, 349, 698),
(745, 70, 2, 9999, 19998),
(746, 65, 2, 349, 698),
(747, 113, 2, 10500, 21000),
(748, 58, 2, 599, 1198),
(749, 132, 2, 59, 118),
(750, 13, 2, 450, 900),
(751, 112, 2, 11999, 23998),
(752, 54, 2, 299, 598),
(753, 32, 2, 349, 698),
(754, 69, 2, 6799, 13598),
(755, 94, 2, 199, 398),
(756, 121, 2, 999, 1998),
(759, 115, 2, 1999, 3998),
(760, 110, 2, 2999, 5998),
(761, 37, 2, 169, 338),
(763, 78, 2, 499, 998),
(764, 137, 2, 999, 1998),
(765, 72, 2, 1999, 3998),
(767, 59, 2, 399, 798),
(769, 142, 2, 1299, 2598),
(770, 62, 2, 399, 798),
(772, 134, 2, 249, 498),
(773, 137, 2, 999, 1998),
(774, 135, 2, 1800, 3600),
(775, 132, 2, 59, 118),
(777, 110, 2, 2999, 5998),
(778, 13, 2, 450, 900),
(779, 126, 2, 9000, 18000),
(780, 94, 2, 199, 398),
(781, 37, 2, 169, 338),
(782, 20, 2, 59, 118),
(783, 72, 2, 1999, 3998),
(784, 38, 2, 5999, 11998),
(785, 31, 2, 20, 40),
(787, 49, 2, 1799, 3598),
(788, 48, 2, 249, 498),
(789, 95, 2, 5999, 11998),
(790, 132, 2, 59, 118),
(791, 122, 2, 450, 900),
(792, 38, 2, 5999, 11998),
(793, 46, 2, 399, 798),
(794, 21, 2, 450, 900),
(795, 145, 2, 13500, 27000),
(796, 132, 2, 59, 118),
(797, 110, 2, 2999, 5998),
(798, 112, 2, 11999, 23998),
(799, 137, 2, 999, 1998),
(800, 62, 2, 399, 798),
(801, 90, 2, 149, 298),
(802, 135, 2, 1800, 3600),
(803, 106, 2, 699, 1398),
(804, 82, 2, 699, 1398),
(805, 117, 2, 1899, 3798),
(806, 97, 2, 399, 798),
(807, 89, 2, 99, 198),
(808, 142, 2, 1299, 2598),
(809, 34, 2, 799, 1598),
(810, 107, 2, 299, 598),
(811, 10, 2, 849, 1698),
(812, 29, 2, 399, 798),
(813, 66, 2, 899, 1798),
(814, 32, 2, 349, 698),
(816, 89, 2, 99, 198),
(818, 62, 2, 399, 798),
(819, 12, 2, 79, 158),
(820, 56, 2, 13499, 26998),
(821, 45, 2, 11499, 22998),
(822, 85, 2, 99, 198),
(823, 76, 2, 16999, 33998),
(824, 33, 2, 399, 798),
(825, 81, 2, 99, 198),
(826, 48, 2, 249, 498),
(828, 110, 2, 2999, 5998),
(829, 38, 2, 5999, 11998),
(830, 130, 2, 2499, 4998),
(831, 75, 2, 349, 698),
(833, 60, 2, 1199, 2398),
(834, 41, 2, 299, 598),
(835, 48, 2, 249, 498),
(836, 138, 2, 1999, 3998),
(840, 132, 2, 59, 118);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id_clientes`);

--
-- Indexes for table `compras`
--
ALTER TABLE `compras`
  ADD PRIMARY KEY (`id_compras`),
  ADD KEY `fk_Compras_Provedores1_idx` (`Provedores_id_provedores`);

--
-- Indexes for table `otrosmovimientos`
--
ALTER TABLE `otrosmovimientos`
  ADD PRIMARY KEY (`id_otrosMovimientos`),
  ADD KEY `fk_OtrosMovimientos_Productos1_idx` (`Productos_id_producto`);

--
-- Indexes for table `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id_productos`);

--
-- Indexes for table `productos_compras`
--
ALTER TABLE `productos_compras`
  ADD KEY `fk_Productos_has_Compras_Compras1_idx` (`Compras_id_compras`),
  ADD KEY `fk_Productos_has_Compras_Productos1_idx` (`Productos_id_productos`);

--
-- Indexes for table `provedores`
--
ALTER TABLE `provedores`
  ADD PRIMARY KEY (`id_provedores`);

--
-- Indexes for table `provedores_productos`
--
ALTER TABLE `provedores_productos`
  ADD PRIMARY KEY (`Provedores_id_provedores`,`Productos_id_producto`),
  ADD KEY `fk_Provedores_has_Productos_Productos1_idx` (`Productos_id_producto`),
  ADD KEY `fk_Provedores_has_Productos_Provedores1_idx` (`Provedores_id_provedores`);

--
-- Indexes for table `prueba`
--
ALTER TABLE `prueba`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`id_ventas`),
  ADD KEY `fk_Ventas_Clientes1_idx` (`Clientes_id_clientes`);

--
-- Indexes for table `ventas_productos`
--
ALTER TABLE `ventas_productos`
  ADD KEY `fk_Ventas_has_Productos_Productos1_idx` (`Productos_id_productos`),
  ADD KEY `fk_Ventas_has_Productos_Ventas1_idx` (`Ventas_id_ventas`),
  ADD KEY `Ventas_id_ventas` (`Ventas_id_ventas`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id_clientes` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT for table `compras`
--
ALTER TABLE `compras`
  MODIFY `id_compras` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=413;

--
-- AUTO_INCREMENT for table `otrosmovimientos`
--
ALTER TABLE `otrosmovimientos`
  MODIFY `id_otrosMovimientos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `productos`
--
ALTER TABLE `productos`
  MODIFY `id_productos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=154;

--
-- AUTO_INCREMENT for table `provedores`
--
ALTER TABLE `provedores`
  MODIFY `id_provedores` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- AUTO_INCREMENT for table `ventas`
--
ALTER TABLE `ventas`
  MODIFY `id_ventas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=845;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `compras`
--
ALTER TABLE `compras`
  ADD CONSTRAINT `fk_Compras_Provedores1` FOREIGN KEY (`Provedores_id_provedores`) REFERENCES `provedores` (`id_provedores`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `otrosmovimientos`
--
ALTER TABLE `otrosmovimientos`
  ADD CONSTRAINT `fk_OtrosMovimientos_Productos1` FOREIGN KEY (`Productos_id_producto`) REFERENCES `productos` (`id_productos`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `productos_compras`
--
ALTER TABLE `productos_compras`
  ADD CONSTRAINT `fk_Productos_has_Compras_Compras1` FOREIGN KEY (`Compras_id_compras`) REFERENCES `compras` (`id_compras`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Productos_has_Compras_Productos1` FOREIGN KEY (`Productos_id_productos`) REFERENCES `productos` (`id_productos`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `provedores_productos`
--
ALTER TABLE `provedores_productos`
  ADD CONSTRAINT `fk_Provedores_has_Productos_Productos1` FOREIGN KEY (`Productos_id_producto`) REFERENCES `productos` (`id_productos`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Provedores_has_Productos_Provedores1` FOREIGN KEY (`Provedores_id_provedores`) REFERENCES `provedores` (`id_provedores`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `ventas`
--
ALTER TABLE `ventas`
  ADD CONSTRAINT `fk_Ventas_Clientes1` FOREIGN KEY (`Clientes_id_clientes`) REFERENCES `clientes` (`id_clientes`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `ventas_productos`
--
ALTER TABLE `ventas_productos`
  ADD CONSTRAINT `fk_Ventas_has_Productos_Productos1` FOREIGN KEY (`Productos_id_productos`) REFERENCES `productos` (`id_productos`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Ventas_has_Productos_Ventas1` FOREIGN KEY (`Ventas_id_ventas`) REFERENCES `ventas` (`id_ventas`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
